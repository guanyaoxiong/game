import uuid
import time
from utils.json_db import read_json, write_json, get_next_id

TOKEN_EXPIRE_TIME = 7200

def generate_token(user_id, user_type):
    token = str(uuid.uuid4())
    token_data = {
        "token": token,
        "user_id": user_id,
        "user_type": user_type,
        "expire_time": time.time() + TOKEN_EXPIRE_TIME
    }
    tokens = read_json("token_cache.json")
    tokens.append(token_data)
    write_json("token_cache.json", tokens)
    return token

def verify_token(token):
    tokens = read_json("token_cache.json")
    now = time.time()
    for t in tokens:
        if t["token"] == token and t["expire_time"] > now:
            t["expire_time"] = now + TOKEN_EXPIRE_TIME
            write_json("token_cache.json", tokens)
            return {"user_id": t["user_id"], "user_type": t["user_type"]}
    return None

def logout(token):
    tokens = read_json("token_cache.json")
    tokens = [t for t in tokens if t["token"] != token]
    write_json("token_cache.json", tokens)
    return True

def player_register(username, password, phone):
    users = read_json("user.json")
    for u in users:
        if u["username"] == username:
            return False, "用户名已存在"
        if u.get("phone") == phone:
            return False, "手机号已被注册"
    user_id = get_next_id("user.json")
    new_user = {
        "user_id": user_id,
        "username": username,
        "password": password,
        "phone": phone,
        "balance": 0.0,
        "role": "player",
        "status": "active",
        "create_time": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    users.append(new_user)
    write_json("user.json", users)
    init_player_tag(user_id)
    return True, "注册成功", user_id

def partner_register(username, password, phone, game, level, price, voice):
    users = read_json("user.json")
    for u in users:
        if u["username"] == username:
            return False, "用户名已存在"
        if u.get("phone") == phone:
            return False, "手机号已被注册"
    user_id = get_next_id("user.json")
    new_user = {
        "user_id": user_id,
        "username": username,
        "password": password,
        "phone": phone,
        "balance": 0.0,
        "role": "partner",
        "status": "active",
        "create_time": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    users.append(new_user)
    write_json("user.json", users)
    
    partners = read_json("partner.json")
    new_partner = {
        "partner_id": user_id,
        "user_id": user_id,
        "game": game,
        "level": level,
        "price": price,
        "voice": voice,
        "status": "offline",
        "audit_status": "pending",
        "good_rate": 0.0,
        "order_count": 0,
        "hour_count": 0,
        "similar_ids": [],
        "introduction": "",
        "tags": [],
        "create_time": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    partners.append(new_partner)
    write_json("partner.json", partners)
    return True, "入驻申请已提交，等待审核", user_id

def login(username, password):
    users = read_json("user.json")
    for u in users:
        if u["username"] == username and u["password"] == password:
            if u["status"] == "banned":
                return False, "账号已被封禁"
            token = generate_token(u["user_id"], u["role"])
            return True, "登录成功", {"token": token, "user": u}
    return False, "用户名或密码错误"

def init_player_tag(user_id):
    tags = read_json("tag.json")
    tags.append({
        "user_id": user_id,
        "game": "英雄联盟",
        "budget": 50,
        "voice_type": "不限",
        "history": [],
        "preferences": [],
        "update_time": time.strftime("%Y-%m-%d %H:%M:%S")
    })
    write_json("tag.json", tags)

def get_user_info(user_id):
    users = read_json("user.json")
    for u in users:
        if u["user_id"] == user_id:
            return u
    return None