import time
from utils.json_db import read_json, write_json, get_next_id

def add_favorite(user_id, partner_id):
    favorites = read_json("favorite.json")
    for f in favorites:
        if f["user_id"] == user_id and f["partner_id"] == partner_id:
            return False, "已收藏"
    
    favorites.append({
        "id": get_next_id("favorite.json"),
        "user_id": user_id,
        "partner_id": partner_id,
        "create_time": time.strftime("%Y-%m-%d %H:%M:%S")
    })
    write_json("favorite.json", favorites)
    return True, "收藏成功"

def remove_favorite(user_id, partner_id):
    favorites = read_json("favorite.json")
    favorites = [f for f in favorites if not (f["user_id"] == user_id and f["partner_id"] == partner_id)]
    write_json("favorite.json", favorites)
    return True, "取消收藏"

def get_favorite_list(user_id):
    favorites = read_json("favorite.json")
    partners = read_json("partner.json")
    users = read_json("user.json")
    
    result = []
    for f in favorites:
        for p in partners:
            if p["partner_id"] == f["partner_id"]:
                user_info = None
                for u in users:
                    if u["user_id"] == p["user_id"]:
                        user_info = u
                        break
                result.append({
                    "partner_id": p["partner_id"],
                    "user_id": p["user_id"],
                    "username": user_info["username"] if user_info else "",
                    "game": p["game"],
                    "level": p["level"],
                    "price": p["price"],
                    "voice": p["voice"],
                    "good_rate": p["good_rate"],
                    "status": p["status"],
                    "create_time": f["create_time"]
                })
                break
    
    return result

def recharge(user_id, amount):
    users = read_json("user.json")
    for u in users:
        if u["user_id"] == user_id:
            u["balance"] += amount
            write_json("user.json", users)
            
            records = read_json("recharge.json")
            records.append({
                "id": get_next_id("recharge.json"),
                "user_id": user_id,
                "amount": amount,
                "status": "success",
                "create_time": time.strftime("%Y-%m-%d %H:%M:%S")
            })
            write_json("recharge.json", records)
            return True, "充值成功"
    return False, "用户不存在"

def submit_complaint(order_id, reason, evidence):
    complaints = read_json("complaint.json")
    complaints.append({
        "id": get_next_id("complaint.json"),
        "order_id": order_id,
        "reason": reason,
        "evidence": evidence,
        "status": "pending",
        "create_time": time.strftime("%Y-%m-%d %H:%M:%S")
    })
    write_json("complaint.json", complaints)
    return True, "投诉已提交"

def get_game_list():
    return ["英雄联盟", "王者荣耀", "绝地求生", "CS2", "原神", "和平精英", "DOTA2", "永劫无间"]

def get_voice_list():
    return ["不限", "萝莉音", "御姐音", "少年音", "大叔音", "磁性音"]