from utils.json_db import read_json, write_json

def calculate_match_score(player_tag, partner):
    score = 0
    
    if player_tag["game"] == partner["game"]:
        score += 15
    
    budget = player_tag["budget"]
    if budget >= partner["price"] - 10 and budget <= partner["price"] + 10:
        score += 10
    elif budget >= partner["price"] - 20 and budget <= partner["price"] + 20:
        score += 5
    
    voice_pref = player_tag["voice_type"]
    if voice_pref == "不限" or voice_pref == partner["voice"]:
        score += 15
    
    score += partner["good_rate"] * 30
    
    similar_count = len(set(player_tag["history"]) & set(partner.get("similar_ids", [])))
    score += min(similar_count * 10, 30)
    
    return round(min(score, 100), 0)

def get_home_recommend(player_id):
    tag_list = read_json("tag.json")
    partner_list = read_json("partner.json")
    user_list = read_json("user.json")
    
    player_tag = None
    for t in tag_list:
        if t["user_id"] == player_id:
            player_tag = t
            break
    if not player_tag:
        return []
    
    result = []
    for p in partner_list:
        if p["status"] != "online" or p["audit_status"] != "pass":
            continue
        
        username = ""
        for u in user_list:
            if u["user_id"] == p["user_id"]:
                username = u["username"]
                break
        
        match_rate = calculate_match_score(player_tag, p)
        result.append({
            "partner_id": p["partner_id"],
            "user_id": p["user_id"],
            "username": username,
            "game": p["game"],
            "level": p["level"],
            "price": p["price"],
            "voice": p["voice"],
            "status": p["status"],
            "good_rate": p["good_rate"],
            "order_count": p["order_count"],
            "hour_count": p["hour_count"],
            "tags": p.get("tags", []),
            "match_rate": match_rate
        })
    
    result.sort(key=lambda x: x["match_rate"], reverse=True)
    return result[:10]

def get_similar_partners(partner_id, limit=5):
    partner_list = read_json("partner.json")
    user_list = read_json("user.json")
    current = None
    for p in partner_list:
        if p["partner_id"] == partner_id:
            current = p
            break
    if not current:
        return []
    
    result = []
    for p in partner_list:
        if p["partner_id"] == partner_id:
            continue
        if p["status"] != "online" or p["audit_status"] != "pass":
            continue
        
        username = ""
        for u in user_list:
            if u["user_id"] == p["user_id"]:
                username = u["username"]
                break
        
        score = 0
        if p["game"] == current["game"]:
            score += 20
        if abs(p["price"] - current["price"]) <= 15:
            score += 15
        if p["voice"] == current["voice"]:
            score += 15
        score += p["good_rate"] * 30
        
        result.append({
            "partner_id": p["partner_id"],
            "user_id": p["user_id"],
            "username": username,
            "game": p["game"],
            "level": p["level"],
            "price": p["price"],
            "voice": p["voice"],
            "status": p["status"],
            "good_rate": p["good_rate"],
            "order_count": p["order_count"],
            "hour_count": p["hour_count"],
            "tags": p.get("tags", []),
            "match_rate": round(min(score, 100), 0)
        })
    
    result.sort(key=lambda x: x["match_rate"], reverse=True)
    return result[:limit]

def wish_match(player_id, game, budget_min, budget_max, voice_type):
    partner_list = read_json("partner.json")
    user_list = read_json("user.json")
    result = []
    
    for p in partner_list:
        if p["status"] != "online" or p["audit_status"] != "pass":
            continue
        if p["game"] != game:
            continue
        if p["price"] < budget_min or p["price"] > budget_max:
            continue
        if voice_type != "不限" and p["voice"] != voice_type:
            continue
        
        username = ""
        for u in user_list:
            if u["user_id"] == p["user_id"]:
                username = u["username"]
                break
        
        score = 30 + p["good_rate"] * 40
        if abs(p["price"] - (budget_min + budget_max) / 2) <= 10:
            score += 30
        elif abs(p["price"] - (budget_min + budget_max) / 2) <= 20:
            score += 15
        
        result.append({
            "partner_id": p["partner_id"],
            "user_id": p["user_id"],
            "username": username,
            "game": p["game"],
            "level": p["level"],
            "price": p["price"],
            "voice": p["voice"],
            "status": p["status"],
            "good_rate": p["good_rate"],
            "order_count": p["order_count"],
            "hour_count": p["hour_count"],
            "tags": p.get("tags", []),
            "match_rate": round(min(score, 100), 0)
        })
    
    result.sort(key=lambda x: x["match_rate"], reverse=True)
    return result[:10]

def update_player_tag(user_id, game=None, budget=None, voice_type=None):
    tags = read_json("tag.json")
    for t in tags:
        if t["user_id"] == user_id:
            if game:
                t["game"] = game
            if budget:
                t["budget"] = budget
            if voice_type:
                t["voice_type"] = voice_type
            t["update_time"] = __import__("time").strftime("%Y-%m-%d %H:%M:%S")
            write_json("tag.json", tags)
            return True
    return False

def record_behavior(user_id, partner_id, behavior_type):
    tags = read_json("tag.json")
    for t in tags:
        if t["user_id"] == user_id:
            if partner_id not in t["history"]:
                t["history"].append(partner_id)
                if len(t["history"]) > 20:
                    t["history"] = t["history"][-20:]
            write_json("tag.json", tags)
            return True
    return False