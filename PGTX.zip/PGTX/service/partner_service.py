import time
from utils.json_db import read_json, write_json

def get_partner_list(game=None, voice=None, price_min=None, price_max=None, sort_by="match"):
    partners = read_json("partner.json")
    users = read_json("user.json")
    
    result = []
    for p in partners:
        if p["audit_status"] != "pass":
            continue
        if game and p["game"] != game:
            continue
        if voice and p["voice"] != voice:
            continue
        if price_min and p["price"] < price_min:
            continue
        if price_max and p["price"] > price_max:
            continue
        
        user_info = None
        for u in users:
            if u["user_id"] == p["user_id"]:
                user_info = u
                break
        
        result.append({
            "partner_id": p["partner_id"],
            "user_id": p["user_id"],
            "username": user_info["username"] if user_info else "",
            "game": p["game"],
            "level": p["level"],
            "price": p["price"],
            "voice": p["voice"],
            "good_rate": p["good_rate"],
            "order_count": p["order_count"],
            "hour_count": p["hour_count"],
            "status": p["status"],
            "introduction": p.get("introduction", "")
        })
    
    if sort_by == "price":
        result.sort(key=lambda x: x["price"])
    elif sort_by == "good_rate":
        result.sort(key=lambda x: x["good_rate"], reverse=True)
    
    return result

def get_partner_detail(partner_id):
    partners = read_json("partner.json")
    users = read_json("user.json")
    
    for p in partners:
        if p["partner_id"] == partner_id:
            user_info = None
            for u in users:
                if u["user_id"] == p["user_id"]:
                    user_info = u
                    break
            
            evaluates = read_json("evaluate.json")
            user_evaluates = []
            for e in evaluates:
                if e["partner_id"] == partner_id:
                    user_evaluates.append(e)
            
            return {
                "partner_id": p["partner_id"],
                "user_id": p["user_id"],
                "username": user_info["username"] if user_info else "",
                "game": p["game"],
                "level": p["level"],
                "price": p["price"],
                "voice": p["voice"],
                "good_rate": p["good_rate"],
                "order_count": p["order_count"],
                "hour_count": p["hour_count"],
                "status": p["status"],
                "introduction": p.get("introduction", ""),
                "tags": p.get("tags", []),
                "evaluates": user_evaluates
            }
    return None

def update_partner_status(user_id, status):
    partners = read_json("partner.json")
    for p in partners:
        if p["user_id"] == user_id:
            p["status"] = status
            write_json("partner.json", partners)
            return True
    return False

def update_partner_info(user_id, game=None, level=None, price=None, voice=None, introduction=None):
    partners = read_json("partner.json")
    for p in partners:
        if p["user_id"] == user_id:
            if game:
                p["game"] = game
            if level:
                p["level"] = level
            if price:
                p["price"] = price
            if voice:
                p["voice"] = voice
            if introduction:
                p["introduction"] = introduction
            p["update_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
            write_json("partner.json", partners)
            return True
    return False

def get_partner_revenue(user_id):
    partners = read_json("partner.json")
    orders = read_json("order.json")
    
    partner_info = None
    for p in partners:
        if p["user_id"] == user_id:
            partner_info = p
            break
    if not partner_info:
        return None
    
    today = time.strftime("%Y-%m-%d")
    month = time.strftime("%Y-%m")
    
    today_orders = 0
    today_revenue = 0
    month_orders = 0
    month_revenue = 0
    
    for o in orders:
        if o["partner_id"] == partner_info["partner_id"] and o["status"] in ["completed", "rated"]:
            if o["create_time"].startswith(today):
                today_orders += 1
                today_revenue += o["total_price"] * 0.9
            if o["create_time"].startswith(month):
                month_orders += 1
                month_revenue += o["total_price"] * 0.9
    
    return {
        "today_orders": today_orders,
        "today_revenue": round(today_revenue, 2),
        "month_orders": month_orders,
        "month_revenue": round(month_revenue, 2),
        "total_orders": partner_info["order_count"],
        "total_hours": partner_info["hour_count"],
        "good_rate": partner_info["good_rate"],
        "balance": __import__("utils.json_db").read_json("user.json")
    }

def apply_withdraw(user_id, amount):
    users = read_json("user.json")
    for u in users:
        if u["user_id"] == user_id:
            if u["balance"] < amount:
                return False, "余额不足"
            u["balance"] -= amount
            write_json("user.json", users)
            
            withdraws = read_json("withdraw.json")
            withdraws.append({
                "id": __import__("utils.json_db").get_next_id("withdraw.json"),
                "user_id": user_id,
                "amount": amount,
                "status": "pending",
                "create_time": time.strftime("%Y-%m-%d %H:%M:%S")
            })
            write_json("withdraw.json", withdraws)
            return True, "提现申请已提交"
    return False, "用户不存在"