import time
from utils.json_db import read_json, write_json, get_next_id

def create_order(player_id, partner_id, hours, game, total_price):
    orders = read_json("order.json")
    order_id = get_next_id("order.json")
    
    new_order = {
        "order_id": order_id,
        "player_id": player_id,
        "partner_id": partner_id,
        "hours": hours,
        "game": game,
        "total_price": total_price,
        "status": "pending",
        "create_time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "pay_time": None,
        "start_time": None,
        "end_time": None,
        "comment": "",
        "rating": 0
    }
    
    orders.append(new_order)
    write_json("order.json", orders)
    
    users = read_json("user.json")
    for u in users:
        if u["user_id"] == player_id:
            if u["balance"] < total_price:
                return False, "余额不足"
            u["balance"] -= total_price
            write_json("user.json", users)
            break
    
    new_order["status"] = "paid"
    new_order["pay_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
    write_json("order.json", orders)
    return True, "订单创建成功", order_id

def get_order_list(user_id, role, status=None):
    orders = read_json("order.json")
    result = []
    
    for o in orders:
        if role == "player" and o["player_id"] != user_id:
            continue
        if role == "partner" and o["partner_id"] != user_id:
            continue
        if status and o["status"] != status:
            continue
        
        result.append(o)
    
    result.sort(key=lambda x: x["create_time"], reverse=True)
    return result

def get_order_detail(order_id):
    orders = read_json("order.json")
    for o in orders:
        if o["order_id"] == order_id:
            return o
    return None

def update_order_status(order_id, status):
    orders = read_json("order.json")
    for o in orders:
        if o["order_id"] == order_id:
            o["status"] = status
            if status == "in_progress":
                o["start_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
            elif status == "completed":
                o["end_time"] = time.strftime("%Y-%m-%d %H:%M:%S")
            write_json("order.json", orders)
            return True
    return False

def add_order_comment(order_id, comment, rating):
    orders = read_json("order.json")
    for o in orders:
        if o["order_id"] == order_id:
            o["comment"] = comment
            o["rating"] = rating
            o["status"] = "rated"
            write_json("order.json", orders)
            
            partners = read_json("partner.json")
            for p in partners:
                if p["partner_id"] == o["partner_id"]:
                    p["order_count"] += 1
                    p["good_rate"] = (p["good_rate"] * (p["order_count"] - 1) + rating / 5) / p["order_count"]
                    p["hour_count"] += o["hours"]
                    write_json("partner.json", partners)
                    break
            
            users = read_json("user.json")
            for u in users:
                if u["user_id"] == o["partner_id"]:
                    u["balance"] += o["total_price"] * 0.9
                    write_json("user.json", users)
                    break
            
            return True
    return False

def apply_refund(order_id, reason):
    orders = read_json("order.json")
    for o in orders:
        if o["order_id"] == order_id:
            if o["status"] != "paid":
                return False, "该状态无法退款"
            o["status"] = "refund_pending"
            o["refund_reason"] = reason
            write_json("order.json", orders)
            return True, "退款申请已提交"
    return False, "订单不存在"

def handle_refund(order_id, agree, admin_note):
    orders = read_json("order.json")
    for o in orders:
        if o["order_id"] == order_id:
            if o["status"] != "refund_pending":
                return False, "订单状态不正确"
            
            if agree:
                o["status"] = "refunded"
                users = read_json("user.json")
                for u in users:
                    if u["user_id"] == o["player_id"]:
                        u["balance"] += o["total_price"]
                        write_json("user.json", users)
                        break
            else:
                o["status"] = "paid"
            
            o["refund_result"] = "同意" if agree else "拒绝"
            o["admin_note"] = admin_note
            write_json("order.json", orders)
            return True, "处理成功"
    return False, "订单不存在"