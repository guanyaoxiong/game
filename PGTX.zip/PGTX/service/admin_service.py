import time
from utils.json_db import read_json, write_json

def audit_partner(partner_id, pass_audit, admin_note):
    partners = read_json("partner.json")
    for p in partners:
        if p["partner_id"] == partner_id:
            if pass_audit:
                p["audit_status"] = "pass"
                p["status"] = "online"
            else:
                p["audit_status"] = "reject"
            p["admin_note"] = admin_note
            write_json("partner.json", partners)
            return True, "审核完成"
    return False, "陪玩不存在"

def get_pending_partners():
    partners = read_json("partner.json")
    users = read_json("user.json")
    
    result = []
    for p in partners:
        if p["audit_status"] == "pending":
            user_info = None
            for u in users:
                if u["user_id"] == p["user_id"]:
                    user_info = u
                    break
            result.append({
                "partner_id": p["partner_id"],
                "user_id": p["user_id"],
                "username": user_info["username"] if user_info else "",
                "game": p["game"],
                "level": p["level"],
                "price": p["price"],
                "voice": p["voice"],
                "create_time": p["create_time"]
            })
    return result

def ban_user(user_id, reason):
    users = read_json("user.json")
    for u in users:
        if u["user_id"] == user_id:
            u["status"] = "banned"
            u["ban_reason"] = reason
            write_json("user.json", users)
            
            partners = read_json("partner.json")
            for p in partners:
                if p["user_id"] == user_id:
                    p["status"] = "offline"
                    write_json("partner.json", partners)
                    break
            
            tokens = read_json("token_cache.json")
            tokens = [t for t in tokens if t["user_id"] != user_id]
            write_json("token_cache.json", tokens)
            
            return True, "封禁成功"
    return False, "用户不存在"

def unban_user(user_id):
    users = read_json("user.json")
    for u in users:
        if u["user_id"] == user_id:
            u["status"] = "active"
            u["ban_reason"] = ""
            write_json("user.json", users)
            return True, "解封成功"
    return False, "用户不存在"

def get_pending_refunds():
    orders = read_json("order.json")
    users = read_json("user.json")
    partners = read_json("partner.json")
    
    result = []
    for o in orders:
        if o["status"] == "refund_pending":
            player_info = None
            partner_info = None
            for u in users:
                if u["user_id"] == o["player_id"]:
                    player_info = u
                    break
            for p in partners:
                if p["partner_id"] == o["partner_id"]:
                    partner_info = p
                    break
            result.append({
                "order_id": o["order_id"],
                "player_username": player_info["username"] if player_info else "",
                "partner_username": partner_info.get("username", "") if partner_info else "",
                "total_price": o["total_price"],
                "create_time": o["create_time"],
                "refund_reason": o.get("refund_reason", "")
            })
    return result

def get_pending_complaints():
    complaints = read_json("complaint.json")
    orders = read_json("order.json")
    users = read_json("user.json")
    
    result = []
    for c in complaints:
        if c["status"] == "pending":
            order_info = None
            player_info = None
            for o in orders:
                if o["order_id"] == c["order_id"]:
                    order_info = o
                    break
            if order_info:
                for u in users:
                    if u["user_id"] == order_info["player_id"]:
                        player_info = u
                        break
            result.append({
                "id": c["id"],
                "order_id": c["order_id"],
                "player_username": player_info["username"] if player_info else "",
                "reason": c["reason"],
                "evidence": c.get("evidence", ""),
                "create_time": c["create_time"]
            })
    return result

def handle_complaint(complaint_id, result, admin_note):
    complaints = read_json("complaint.json")
    for c in complaints:
        if c["id"] == complaint_id:
            c["status"] = "handled"
            c["result"] = result
            c["admin_note"] = admin_note
            write_json("complaint.json", complaints)
            return True, "处理完成"
    return False, "投诉不存在"

def get_statistics():
    users = read_json("user.json")
    partners = read_json("partner.json")
    orders = read_json("order.json")
    evaluates = read_json("evaluate.json")
    
    player_count = sum(1 for u in users if u["role"] == "player")
    partner_count = sum(1 for p in partners if p["audit_status"] == "pass")
    order_count = len(orders)
    completed_count = sum(1 for o in orders if o["status"] in ["completed", "rated"])
    
    total_revenue = sum(o["total_price"] for o in orders if o["status"] in ["completed", "rated"])
    
    avg_rating = 0
    if evaluates:
        avg_rating = sum(e["rating"] for e in evaluates) / len(evaluates)
    
    return {
        "player_count": player_count,
        "partner_count": partner_count,
        "order_count": order_count,
        "completed_count": completed_count,
        "total_revenue": round(total_revenue, 2),
        "avg_rating": round(avg_rating, 2)
    }

def get_user_list(page=1, page_size=20):
    users = read_json("user.json")
    start = (page - 1) * page_size
    end = start + page_size
    return users[start:end], len(users)