def get_header(user_info=None, active_page=''):
    avatar_url = "https://api.dicebear.com/7.x/avataaars/svg?seed=guest"
    if user_info:
        username = user_info.get('username', '游客')
        avatar_url = user_info.get('avatar', f"https://api.dicebear.com/7.x/avataaars/svg?seed={username}")

    login_html = '<a href="/login" class="nav-link">登录</a><a href="/register" class="nav-link register-btn">注册</a>'
    if user_info:
        balance = user_info.get("balance", 0)
        login_html = f'''
        <div class="user-area">
            <img src="{avatar_url}" alt="头像" class="user-avatar" onerror="this.src='https://api.dicebear.com/7.x/avataaars/svg?seed=default'">
            <span class="user-name">{user_info["username"]}</span>
            <div class="user-dropdown">
                <a href="/center">个人中心</a>
                <a href="/partner/workspace">陪玩工作台</a>
                <a href="/admin">管理后台</a>
                <a href="/feedback">问题反馈</a>
                <a href="/forum">游戏论坛</a>
                <a href="/api/v1/logout">退出登录</a>
            </div>
        </div>
        <span class="nav-link balance">余额: {balance:.2f}元</span>
        '''

    return f'''
    <header class="site-header">
        <div class="header-container">
            <a href="/" class="logo">
                <span class="logo-icon">🎮</span>
                <span class="logo-text">AI陪玩</span>
            </a>
            <nav class="main-nav">
                <a href="/" class="nav-item {"active" if active_page == "home" else ""}">首页</a>
                <a href="/partners" class="nav-item {"active" if active_page == "partners" else ""}">陪玩列表</a>
                <a href="/wish" class="nav-item {"active" if active_page == "wish" else ""}">心愿匹配</a>
                <a href="/forum" class="nav-item {"active" if active_page == "forum" else ""}">游戏论坛</a>
                <a href="/chat" class="nav-item {"active" if active_page == "chat" else ""}">消息中心</a>
                <a href="/feedback" class="nav-item {"active" if active_page == "feedback" else ""}">问题反馈</a>
            </nav>
            <div class="nav-right">
                {login_html}
            </div>
        </div>
    </header>
    '''

def get_footer():
    return '''
    <footer class="site-footer">
        <div class="footer-content">
            <div class="footer-section">
                <h4>关于我们</h4>
                <p>AI智能陪玩推荐平台</p>
                <p>纯Python零依赖开发</p>
            </div>
            <div class="footer-section">
                <h4>快速链接</h4>
                <a href="/">首页</a>
                <a href="/partners">陪玩列表</a>
                <a href="/wish">心愿匹配</a>
                <a href="/forum">游戏论坛</a>
                <a href="/feedback">问题反馈</a>
            </div>
            <div class="footer-section">
                <h4>联系我们</h4>
                <p>📧 support@gameplaymate.com</p>
                <p>📞 400-888-8888</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2024 AI陪玩推荐平台</p>
        </div>
    </footer>
    '''

def get_partner_card(partner, match_rate=None):
    status_color = "online" if partner["status"] == "online" else "offline"
    status_text = "在线" if partner["status"] == "online" else "离线"

    match_tag = ""
    if match_rate:
        if match_rate >= 90:
            match_tag = f'<span class="match-tag gold">⭐ {match_rate}%</span>'
        elif match_rate >= 70:
            match_tag = f'<span class="match-tag blue">{match_rate}%</span>'
        else:
            match_tag = f'<span class="match-tag gray">{match_rate}%</span>'

    good_rate_display = int(partner["good_rate"] * 100)

    tags_html = ""
    if partner.get("tags"):
        for tag in partner["tags"][:3]:
            tags_html += f'<span class="partner-tag">{tag}</span>'

    avatar_seed = partner.get("username", "user")
    avatar_url = partner.get("avatar", f"https://api.dicebear.com/7.x/avataaars/svg?seed={avatar_seed}")

    return f'''
    <div class="partner-card" onclick="location.href='/partner/{partner["partner_id"]}'">
        {match_tag}
        <div class="card-header">
            <img src="{avatar_url}" alt="头像" class="partner-avatar" onerror="this.src='https://api.dicebear.com/7.x/avataaars/svg?seed={avatar_seed}'">
            <div class="status-indicator {status_color}">
                <span class="status-dot"></span>
                <span class="status-text">{status_text}</span>
            </div>
        </div>
        <div class="card-body">
            <h3 class="partner-name">{partner["username"]}</h3>
            <div class="partner-tags">{tags_html}</div>
            <div class="partner-info">
                <div class="info-item">🎮 {partner["game"]}</div>
                <div class="info-item">🏆 {partner["level"]}</div>
                <div class="info-item">🎤 {partner["voice"]}</div>
            </div>
        </div>
        <div class="card-footer">
            <div class="price-section">
                <span class="price-label">时薪</span>
                <span class="price-value">{partner["price"]}</span>
                <span class="price-unit">元</span>
            </div>
            <div class="rating-section">
                <span class="rating-text">⭐ {good_rate_display}%</span>
            </div>
        </div>
        <div class="card-stats">
            <div class="stat-item">
                <span class="stat-value">{partner["order_count"]}</span>
                <span class="stat-label">接单</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">{partner["hour_count"]}h</span>
                <span class="stat-label">服务</span>
            </div>
        </div>
    </div>
    '''

def get_game_category_card(game_name, icon, count, color):
    return f'''
    <div class="game-card" onclick="location.href='/partners?game={game_name}'" style="background: linear-gradient(135deg, {color} 0%, {color}88 100%);">
        <div class="game-icon">{icon}</div>
        <div class="game-name">{game_name}</div>
        <div class="game-count">{count}位陪玩</div>
    </div>
    '''

def get_home_page(user_info=None, recommend_list=None, hot_partners=None):
    recommend_html = ""
    if recommend_list:
        for p in recommend_list:
            recommend_html += get_partner_card(p, p.get("match_rate"))
    else:
        recommend_html = '<div class="empty-state"><p>登录后查看AI个性化推荐</p><a href="/login" class="login-link">立即登录</a></div>'

    hot_html = ""
    if hot_partners:
        for p in hot_partners:
            hot_html += get_partner_card(p)

    games_data = [
        ("英雄联盟", "LOL", 12, "#007bff"),
        ("王者荣耀", "王者", 10, "#ff6b6b"),
        ("绝地求生", "吃鸡", 8, "#4ecdc4"),
        ("原神", "原神", 7, "#a55eea"),
        ("CS2", "CS2", 6, "#45b7d1"),
        ("和平精英", "精英", 7, "#f9ca24")
    ]
    game_cards = ""
    for game in games_data:
        game_cards += get_game_category_card(game[0], game[1], game[2], game[3])

    user_count = 71
    partner_count = 50
    order_count = 150

    return f'''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI陪玩 - 智能推荐游戏陪玩平台</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, sans-serif; background: #0a0a14; color: #fff; min-height: 100vh; }}
        a {{ text-decoration: none; color: inherit; }}

        .site-header {{
            background: rgba(15, 15, 25, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            position: sticky;
            top: 0;
            z-index: 1000;
        }}
        .header-container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            height: 72px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        .logo {{ display: flex; align-items: center; gap: 10px; }}
        .logo-icon {{ font-size: 36px; }}
        .logo-text {{
            font-size: 26px;
            font-weight: 700;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .main-nav {{ display: flex; gap: 8px; }}
        .nav-item {{
            padding: 10px 20px;
            color: #9ca3af;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }}
        .nav-item:hover {{ color: #00d4ff; background: rgba(0, 212, 255, 0.08); }}
        .nav-item.active {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}
        .nav-right {{ display: flex; align-items: center; gap: 16px; }}
        .nav-link {{
            padding: 8px 16px;
            color: #9ca3af;
            border-radius: 10px;
            transition: all 0.3s ease;
        }}
        .nav-link:hover {{ color: #00d4ff; }}
        .nav-link.register-btn {{ background: linear-gradient(135deg, #00d4ff, #7c3aed); color: #fff; }}
        .nav-link.balance {{ color: #4ade80; font-weight: 600; }}
        .user-area {{
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 16px;
            border-radius: 16px;
            cursor: pointer;
            position: relative;
        }}
        .user-avatar {{
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid rgba(0, 212, 255, 0.5);
        }}
        .user-name {{ font-weight: 500; color: #fff; }}
        .user-dropdown {{
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: rgba(20, 20, 35, 0.98);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 8px;
            min-width: 180px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
        }}
        .user-area:hover .user-dropdown {{ opacity: 1; visibility: visible; transform: translateY(0); }}
        .dropdown-item {{
            display: block;
            padding: 12px 16px;
            color: #9ca3af;
            border-radius: 10px;
        }}
        .dropdown-item:hover {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}

        .hero-section {{
            background: linear-gradient(135deg, #0f0f1f 0%, #1a1a2e 50%, #16213e 100%);
            padding: 100px 24px;
            position: relative;
        }}
        .hero-content {{
            max-width: 1200px;
            margin: 0 auto;
            text-align: center;
        }}
        .hero-badge {{
            display: inline-block;
            padding: 8px 20px;
            background: rgba(0, 212, 255, 0.1);
            border: 1px solid rgba(0, 212, 255, 0.3);
            border-radius: 50px;
            font-size: 14px;
            color: #00d4ff;
            margin-bottom: 24px;
        }}
        .hero-title {{
            font-size: 56px;
            font-weight: 700;
            line-height: 1.2;
            margin-bottom: 20px;
        }}
        .hero-title .gradient-text {{
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .hero-subtitle {{
            font-size: 20px;
            color: #9ca3af;
            margin-bottom: 40px;
        }}
        .hero-stats {{
            display: flex;
            justify-content: center;
            gap: 60px;
            margin-top: 60px;
        }}
        .hero-stat {{ text-align: center; }}
        .hero-stat-value {{
            font-size: 42px;
            font-weight: 700;
            background: linear-gradient(135deg, #00d4ff, #4ade80);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .hero-stat-label {{
            font-size: 16px;
            color: #6b7280;
            margin-top: 8px;
        }}

        .main-container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 60px 24px;
        }}

        .section-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
        }}
        .section-title {{
            font-size: 28px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 12px;
        }}
        .section-title::before {{
            content: '';
            width: 4px;
            height: 28px;
            background: linear-gradient(180deg, #00d4ff, #7c3aed);
            border-radius: 2px;
        }}
        .section-link {{
            color: #00d4ff;
            font-size: 16px;
            padding: 8px 16px;
            border-radius: 8px;
        }}
        .section-link:hover {{ background: rgba(0, 212, 255, 0.1); }}

        .partner-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 24px;
        }}
        .partner-card {{
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 20px;
            padding: 28px;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(255, 255, 255, 0.06);
            position: relative;
            overflow: hidden;
        }}
        .partner-card::before {{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #00d4ff, #7c3aed);
            opacity: 0;
            transition: opacity 0.3s ease;
        }}
        .partner-card:hover {{
            transform: translateY(-8px);
            box-shadow: 0 25px 50px rgba(0, 212, 255, 0.15);
            border-color: rgba(0, 212, 255, 0.3);
        }}
        .partner-card:hover::before {{ opacity: 1; }}

        .match-tag {{
            position: absolute;
            top: 16px;
            right: 16px;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }}
        .match-tag.gold {{ background: linear-gradient(135deg, #fbbf24, #f59e0b); color: #000; }}
        .match-tag.blue {{ background: linear-gradient(135deg, #00d4ff, #0891b2); color: #fff; }}
        .match-tag.gray {{ background: rgba(255, 255, 255, 0.1); color: #9ca3af; }}

        .card-header {{
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 20px;
        }}
        .partner-avatar {{
            width: 64px;
            height: 64px;
            border-radius: 50%;
            border: 3px solid rgba(0, 212, 255, 0.3);
        }}
        .status-indicator {{
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
        }}
        .status-indicator.online {{ background: rgba(74, 222, 128, 0.15); color: #4ade80; }}
        .status-indicator.offline {{ background: rgba(255, 255, 255, 0.1); color: #6b7280; }}
        .status-dot {{
            width: 8px;
            height: 8px;
            border-radius: 50%;
        }}
        .status-indicator.online .status-dot {{
            background: #4ade80;
            animation: pulse 2s infinite;
        }}
        .status-indicator.offline .status-dot {{ background: #6b7280; }}
        @keyframes pulse {{
            0%, 100% {{ opacity: 1; transform: scale(1); }}
            50% {{ opacity: 0.6; transform: scale(1.2); }}
        }}

        .partner-name {{ font-size: 20px; font-weight: 600; margin-bottom: 12px; }}
        .partner-tags {{
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 16px;
        }}
        .partner-tag {{
            padding: 4px 12px;
            background: rgba(0, 212, 255, 0.1);
            border-radius: 12px;
            font-size: 12px;
            color: #00d4ff;
        }}
        .partner-info {{
            display: flex;
            flex-direction: column;
            gap: 10px;
        }}
        .info-item {{
            font-size: 14px;
            color: #9ca3af;
        }}

        .card-footer {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
        }}
        .price-section {{
            display: flex;
            align-items: baseline;
            gap: 4px;
        }}
        .price-label {{ font-size: 13px; color: #6b7280; }}
        .price-value {{ font-size: 28px; font-weight: 700; color: #f472b6; }}
        .price-unit {{ font-size: 14px; color: #f472b6; }}
        .rating-text {{ font-size: 15px; color: #fbbf24; }}

        .card-stats {{
            display: flex;
            justify-content: space-around;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
        }}
        .stat-item {{ text-align: center; }}
        .stat-value {{
            font-size: 18px;
            font-weight: 600;
            color: #00d4ff;
        }}
        .stat-label {{
            font-size: 12px;
            color: #6b7280;
            display: block;
            margin-top: 4px;
        }}

        .game-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
        }}
        .game-card {{
            padding: 32px 24px;
            border-radius: 20px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid transparent;
        }}
        .game-card:hover {{
            transform: translateY(-6px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            border-color: rgba(255, 255, 255, 0.1);
        }}
        .game-icon {{ font-size: 36px; font-weight: 700; margin-bottom: 12px; }}
        .game-name {{ font-size: 18px; font-weight: 600; margin-bottom: 8px; }}
        .game-count {{ font-size: 14px; color: rgba(255, 255, 255, 0.7); }}

        .features {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
            margin-top: 60px;
        }}
        .feature-card {{
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border: 1px solid rgba(255, 255, 255, 0.06);
            border-radius: 20px;
            padding: 32px;
            text-align: center;
            transition: all 0.3s ease;
        }}
        .feature-card:hover {{
            transform: translateY(-4px);
            border-color: rgba(0, 212, 255, 0.3);
        }}
        .feature-icon {{
            width: 72px;
            height: 72px;
            border-radius: 50%;
            background: linear-gradient(135deg, rgba(0, 212, 255, 0.2), rgba(124, 58, 237, 0.2));
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            font-size: 32px;
        }}
        .feature-title {{
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 12px;
        }}
        .feature-desc {{
            font-size: 14px;
            color: #6b7280;
            line-height: 1.6;
        }}

        .empty-state {{
            text-align: center;
            padding: 60px;
            color: #6b7280;
        }}
        .login-link {{
            display: inline-block;
            margin-top: 20px;
            padding: 14px 40px;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            color: #fff;
            border-radius: 30px;
            font-weight: 600;
        }}

        .site-footer {{
            background: rgba(15, 15, 25, 0.95);
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            padding: 60px 24px 30px;
            margin-top: 80px;
        }}
        .footer-content {{
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
        }}
        .footer-section h4 {{ font-size: 18px; color: #fff; margin-bottom: 16px; }}
        .footer-section p, .footer-section a {{
            color: #6b7280;
            font-size: 14px;
            line-height: 2;
            display: block;
        }}
        .footer-section a:hover {{ color: #00d4ff; }}
        .footer-bottom {{
            max-width: 1400px;
            margin: 40px auto 0;
            padding-top: 24px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
            text-align: center;
            color: #6b7280;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    {get_header(user_info)}

    <section class="hero-section">
        <div class="hero-content">
            <div class="hero-badge">✨ 纯Python开发的AI智能推荐平台</div>
            <h1 class="hero-title">
                找到最适合你的<span class="gradient-text">游戏陪玩</span>
            </h1>
            <p class="hero-subtitle">基于创新混合推荐算法，为你精准匹配心仪的陪玩伙伴</p>
            <div class="hero-stats">
                <div class="hero-stat">
                    <div class="hero-stat-value">{user_count}+</div>
                    <div class="hero-stat-label">注册用户</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-value">{partner_count}</div>
                    <div class="hero-stat-label">认证陪玩师</div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-value">{order_count}+</div>
                    <div class="hero-stat-label">完成订单</div>
                </div>
            </div>
        </div>
    </section>

    <div class="main-container">
        <section class="section">
            <div class="section-header">
                <h2 class="section-title">🤖 AI智能推荐</h2>
                <a href="/partners" class="section-link">查看全部 →</a>
            </div>
            <div class="partner-grid">
                {recommend_html}
            </div>
        </section>

        <section class="section">
            <div class="section-header">
                <h2 class="section-title">🎮 热门游戏</h2>
            </div>
            <div class="game-grid">
                {game_cards}
            </div>
        </section>

        <section class="section">
            <div class="section-header">
                <h2 class="section-title">🔥 热门陪玩</h2>
                <a href="/partners?sort=good_rate" class="section-link">查看全部 →</a>
            </div>
            <div class="partner-grid">
                {hot_html}
            </div>
        </section>

        <div class="features">
            <div class="feature-card">
                <div class="feature-icon">🎯</div>
                <h3 class="feature-title">AI智能匹配</h3>
                <p class="feature-desc">基于用户画像和行为分析，三层混合推荐算法精准匹配</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">✅</div>
                <h3 class="feature-title">严格审核</h3>
                <p class="feature-desc">所有陪玩师经过实名认证和资质审核，服务质量有保障</p>
            </div>
            <div class="feature-card">
                <div class="feature-icon">🔒</div>
                <h3 class="feature-title">安全交易</h3>
                <p class="feature-desc">平台担保交易，资金安全有保障，支持全额退款</p>
            </div>
        </div>
    </div>

    {get_footer()}
</body>
</html>
    '''