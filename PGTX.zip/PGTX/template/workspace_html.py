from template.home_html import get_header, get_footer

def get_workspace_page(user_info=None, partner_info=None, orders=None):
    if not user_info or not partner_info:
        return "<h1>请先登录</h1>"
    
    status_text = "在线" if partner_info["status"] == "online" else "离线"
    status_action = "offline" if partner_info["status"] == "online" else "online"
    status_btn_text = "离线休息" if partner_info["status"] == "online" else "上线接单"
    
    orders_html = ""
    if orders:
        status_map = {"pending": "待支付", "paid": "待开始", "in_progress": "进行中", "completed": "已完成", "rated": "已评价"}
        for o in orders:
            start_btn = f'<button onclick="startOrder({o["order_id"]})">开始服务</button>' if o["status"] == "paid" else ""
            complete_btn = f'<button onclick="completeOrder({o["order_id"]})">完成服务</button>' if o["status"] == "in_progress" else ""
            orders_html += f'''
            <div class="order-item">
                <div class="order-header">
                    <span class="order-id">订单号: {o["order_id"]}</span>
                    <span class="order-status {o["status"]}">{status_map.get(o["status"], o["status"])}</span>
                </div>
                <div class="order-body">
                    <span class="order-game">🎮 {o["game"]}</span>
                    <span class="order-hours">时长: {o["hours"]}小时</span>
                    <span class="order-price">¥{o["total_price"]}</span>
                </div>
                <div class="order-footer">
                    <span class="order-time">{o["create_time"]}</span>
                    <div class="order-actions">
                        {start_btn}
                        {complete_btn}
                    </div>
                </div>
            </div>
            '''
    
    return f'''
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>陪玩工作台</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #161a29; color: #fff; }}
            .container {{ max-width: 1200px; margin: 0 auto; padding: 0 20px; }}
            
            .header {{ background: linear-gradient(135deg, #222740 0%, #161a29 100%); padding: 16px 0; position: sticky; top: 0; z-index: 100; }}
            .header .container {{ display: flex; justify-content: space-between; align-items: center; }}
            .logo h1 {{ font-size: 24px; }}
            .logo a {{ color: #007bff; text-decoration: none; }}
            .nav {{ display: flex; gap: 24px; align-items: center; }}
            .nav-link {{ color: #ccc; text-decoration: none; font-size: 16px; }}
            .nav-link:hover, .nav-link.active {{ color: #007bff; }}
            
            .main-content {{ display: flex; gap: 24px; padding: 32px 0; }}
            .sidebar {{ width: 280px; flex-shrink: 0; }}
            .status-card {{ background: #222740; border-radius: 12px; padding: 24px; text-align: center; }}
            .current-status {{ font-size: 24px; margin-bottom: 16px; }}
            .current-status.online {{ color: #4ade80; }}
            .current-status.offline {{ color: #666; }}
            .status-btn {{ padding: 12px 24px; background: #007bff; border: none; border-radius: 8px; color: #fff; cursor: pointer; font-size: 16px; }}
            
            .info-card {{ background: #222740; border-radius: 12px; padding: 24px; margin-top: 16px; }}
            .info-item {{ margin-bottom: 12px; }}
            .info-item strong {{ color: #007bff; }}
            
            .main-area {{ flex: 1; }}
            .section-card {{ background: #222740; border-radius: 12px; padding: 24px; margin-bottom: 24px; }}
            .section-title {{ font-size: 20px; margin-bottom: 20px; }}
            
            .order-item {{ padding: 16px; background: #161a29; border-radius: 8px; margin-bottom: 12px; }}
            .order-header {{ display: flex; justify-content: space-between; margin-bottom: 8px; }}
            .order-id {{ font-size: 14px; }}
            .order-status {{ font-size: 14px; padding: 4px 12px; border-radius: 12px; }}
            .order-status.paid {{ background: #ffd700; color: #000; }}
            .order-status.in_progress {{ background: #007bff; }}
            .order-status.completed {{ background: #4ade80; color: #000; }}
            .order-body {{ display: flex; gap: 24px; margin-bottom: 8px; }}
            .order-game, .order-hours, .order-price {{ font-size: 14px; }}
            .order-price {{ color: #ff6633; }}
            .order-footer {{ display: flex; justify-content: space-between; }}
            .order-time {{ font-size: 12px; color: #666; }}
            .order-actions button {{ padding: 6px 12px; background: #007bff; border: none; border-radius: 6px; color: #fff; cursor: pointer; margin-left: 8px; }}
            
            .edit-form {{ display: flex; flex-direction: column; gap: 16px; }}
            .form-group {{ display: flex; flex-direction: column; }}
            .form-label {{ font-size: 14px; color: #999; margin-bottom: 8px; }}
            .form-input, .form-select {{ padding: 12px; background: #161a29; border: 1px solid #333; border-radius: 8px; color: #fff; }}
            .edit-btn {{ padding: 12px; background: #007bff; border: none; border-radius: 8px; color: #fff; cursor: pointer; }}
            
            .footer {{ background: #222740; padding: 24px 0; text-align: center; color: #666; margin-top: 40px; }}
        </style>
    </head>
    <body>
        {get_header(user_info)}
        
        <div class="container">
            <div class="main-content">
                <aside class="sidebar">
                    <div class="status-card">
                        <div class="current-status {partner_info["status"]}">当前状态: {status_text}</div>
                        <button class="status-btn" onclick="updateStatus('{status_action}')">{status_btn_text}</button>
                    </div>
                    
                    <div class="info-card">
                        <h3>服务信息</h3>
                        <div class="info-item"><strong>🎮 游戏:</strong> {partner_info["game"]}</div>
                        <div class="info-item"><strong>🏆 段位:</strong> {partner_info["level"]}</div>
                        <div class="info-item"><strong>💰 时薪:</strong> ¥{partner_info["price"]}/小时</div>
                        <div class="info-item"><strong>🎤 声线:</strong> {partner_info["voice"]}</div>
                        <div class="info-item"><strong>⭐ 好评率:</strong> {(partner_info["good_rate"]*100):.0f}%</div>
                        <div class="info-item"><strong>📊 接单量:</strong> {partner_info["order_count"]}</div>
                    </div>
                </aside>
                
                <div class="main-area">
                    <div class="section-card">
                        <h3 class="section-title">我的订单</h3>
                        {orders_html}
                        {not orders and "<p style='text-align:center;color:#666'>暂无订单</p>" or ""}
                    </div>
                    
                    <div class="section-card">
                        <h3 class="section-title">编辑服务信息</h3>
                        <form class="edit-form" onsubmit="editInfo(event)">
                            <div class="form-group">
                                <label class="form-label">游戏</label>
                                <select class="form-select" id="game">
                                    <option value="英雄联盟">英雄联盟</option>
                                    <option value="王者荣耀">王者荣耀</option>
                                    <option value="绝地求生">绝地求生</option>
                                    <option value="CS2">CS2</option>
                                    <option value="原神">原神</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">段位</label>
                                <input type="text" class="form-input" id="level" value="{partner_info["level"]}">
                            </div>
                            <div class="form-group">
                                <label class="form-label">时薪</label>
                                <input type="number" class="form-input" id="price" value="{partner_info["price"]}">
                            </div>
                            <div class="form-group">
                                <label class="form-label">声线</label>
                                <select class="form-select" id="voice">
                                    <option value="萝莉音">萝莉音</option>
                                    <option value="御姐音">御姐音</option>
                                    <option value="少年音">少年音</option>
                                    <option value="大叔音">大叔音</option>
                                    <option value="磁性音">磁性音</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="form-label">个人介绍</label>
                                <textarea class="form-input" id="introduction" rows="3">{partner_info.get("introduction", "")}</textarea>
                            </div>
                            <button type="submit" class="edit-btn">保存修改</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        {get_footer()}
        
        <script>
            document.getElementById('game').value = '{partner_info["game"]}';
            document.getElementById('voice').value = '{partner_info["voice"]}';
            
            function updateStatus(status) {{
                fetch('/api/v1/partner/status', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ status }})
                }}).then(res => res.json()).then(data => {{
                    alert(data.msg);
                    if (data.code == 200) location.reload();
                }});
            }}
            
            function editInfo(e) {{
                e.preventDefault();
                const game = document.getElementById('game').value;
                const level = document.getElementById('level').value;
                const price = parseFloat(document.getElementById('price').value);
                const voice = document.getElementById('voice').value;
                const introduction = document.getElementById('introduction').value;
                
                fetch('/api/v1/partner/edit', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ game, level, price, voice, introduction }})
                }}).then(res => res.json()).then(data => {{
                    alert(data.msg);
                    if (data.code == 200) location.reload();
                }});
            }}
            
            function startOrder(order_id) {{
                fetch('/api/v1/order/update', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ order_id, status: 'in_progress' }})
                }}).then(res => res.json()).then(data => {{
                    alert(data.msg);
                    if (data.code == 200) location.reload();
                }});
            }}
            
            function completeOrder(order_id) {{
                fetch('/api/v1/order/update', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ order_id, status: 'completed' }})
                }}).then(res => res.json()).then(data => {{
                    alert(data.msg);
                    if (data.code == 200) location.reload();
                }});
            }}
        </script>
    </body>
    </html>
    '''