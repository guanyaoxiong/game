from template.home_html import get_header, get_footer

def get_chat_page(user_info=None, chat_list=None, current_chat=None, messages=None):
    current_chat_id = current_chat['id'] if current_chat else 'null'
    self_avatar = user_info.get("avatar", "https://api.dicebear.com/7.x/avataaars/svg?seed=" + (user_info.get('username', 'user') if user_info else 'guest')) if user_info else "https://api.dicebear.com/7.x/avataaars/svg?seed=guest"
    other_avatar = current_chat.get("avatar", "") if current_chat else ""
    
    chat_list_html = ""
    if chat_list:
        for chat in chat_list:
            unread_count = chat.get("unread_count", 0)
            unread_html = '<span class="unread-badge">%d</span>' % unread_count if unread_count > 0 else ''
            chat_list_html += '''
            <div class="chat-item" onclick="selectChat(%s, '%s', '%s')">
                <img src="%s" alt="%s" class="chat-avatar">
                <div class="chat-info">
                    <div class="chat-name">%s</div>
                    <div class="chat-last-message">%s</div>
                </div>
                <div class="chat-meta">
                    <span class="chat-time">%s</span>
                    %s
                </div>
            </div>
            ''' % (chat['id'], chat['name'], chat['avatar'], chat['avatar'], chat['name'], chat['name'], chat['last_message'], chat['last_time'], unread_html)

    messages_html = ""
    if messages:
        for msg in messages:
            is_self = msg.get("is_self", False)
            align_class = "msg-right" if is_self else "msg-left"
            avatar_url = self_avatar if is_self else other_avatar
            messages_html += '''
            <div class="message-item %s">
                <img src="%s" class="msg-avatar">
                <div class="msg-content">
                    <div class="msg-bubble">%s</div>
                    <div class="msg-time">%s</div>
                </div>
            </div>
            ''' % (align_class, avatar_url, msg["content"], msg["time"])

    current_chat_html = ""
    if current_chat:
        current_chat_html = '''
            <div class="chat-header">
                <img src="%s" alt="%s" class="chat-header-avatar">
                <div class="chat-header-info">
                    <div class="chat-header-name">%s</div>
                    <div class="chat-header-status">Online</div>
                </div>
                <div class="chat-actions">
                    <button class="action-btn secondary" onclick="location.href='/partner/%s'">View Profile</button>
                    <button class="action-btn primary" onclick="location.href='/wish?game=%s'">Book Now</button>
                </div>
            </div>
            
            <div class="message-area" id="messageArea">
                %s
            </div>
            
            <div class="input-area">
                <input type="text" class="msg-input" id="msgInput" placeholder="Enter message..." onkeydown="if(event.keyCode==13)sendMessage()">
                <button class="send-btn" onclick="sendMessage()">Send</button>
            </div>
        ''' % (current_chat['avatar'], current_chat['name'], current_chat['name'], current_chat.get("partner_id", ""), current_chat.get("game", ""), messages_html)
    else:
        current_chat_html = '''
            <div class="empty-state">
                <div class="empty-icon">Chat</div>
                <div class="empty-text">Select a chat to start conversation</div>
            </div>
        '''

    header_html = get_header(user_info, active_page='chat')
    footer_html = get_footer()
    
    return '''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message Center</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #161a29; color: #fff; }
        
        .site-header {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f0f1f 100%);
            backdrop-filter: blur(20px);
            padding: 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        .header-container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            height: 72px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .logo { display: flex; align-items: center; gap: 10px; text-decoration: none; }
        .logo-icon { font-size: 36px; }
        .logo-text {
            font-size: 26px;
            font-weight: 700;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .main-nav { display: flex; gap: 8px; }
        .nav-item {
            padding: 10px 20px;
            color: #9ca3af;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        .nav-item:hover { color: #00d4ff; background: rgba(0, 212, 255, 0.08); }
        .nav-item.active { background: rgba(0, 212, 255, 0.1); color: #00d4ff; }
        .nav-right { display: flex; align-items: center; gap: 16px; }
        .nav-link {
            padding: 8px 16px;
            color: #9ca3af;
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .nav-link:hover { color: #00d4ff; }
        .nav-link.register-btn { background: linear-gradient(135deg, #00d4ff, #7c3aed); color: #fff; }
        .nav-link.balance { color: #4ade80; font-weight: 600; }
        .user-area {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 16px;
            border-radius: 16px;
            cursor: pointer;
            position: relative;
        }
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid rgba(0, 212, 255, 0.5);
        }
        .user-name { font-weight: 500; color: #fff; }
        .user-dropdown {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: rgba(20, 20, 35, 0.98);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 8px;
            min-width: 180px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
        }
        .user-area:hover .user-dropdown { opacity: 1; visibility: visible; transform: translateY(0); }
        .dropdown-item {
            display: block;
            padding: 12px 16px;
            color: #9ca3af;
            text-decoration: none;
            border-radius: 10px;
        }
        .dropdown-item:hover { background: rgba(0, 212, 255, 0.1); color: #00d4ff; }

        .chat-container {
            display: flex;
            max-width: 1400px;
            margin: 40px auto;
            padding: 0 24px;
            height: calc(100vh - 152px);
        }
        
        .chat-sidebar {
            width: 320px;
            background: #222740;
            border-radius: 16px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .sidebar-title {
            font-size: 20px;
            font-weight: 600;
        }
        
        .chat-list {
            flex: 1;
            overflow-y: auto;
        }
        
        .chat-item {
            display: flex;
            align-items: center;
            padding: 16px 20px;
            cursor: pointer;
            transition: background 0.3s ease;
            border-bottom: 1px solid rgba(255, 255, 255, 0.03);
        }
        
        .chat-item:hover { background: rgba(0, 212, 255, 0.05); }
        .chat-item.active { background: rgba(0, 212, 255, 0.1); }
        
        .chat-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            margin-right: 14px;
            border: 2px solid rgba(0, 212, 255, 0.3);
        }
        
        .chat-info { flex: 1; overflow: hidden; }
        
        .chat-name {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 4px;
        }
        
        .chat-last-message {
            font-size: 13px;
            color: #9ca3af;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
        .chat-meta {
            text-align: right;
        }
        
        .chat-time {
            font-size: 12px;
            color: #666;
            display: block;
            margin-bottom: 4px;
        }
        
        .unread-badge {
            background: #ff6633;
            color: #fff;
            font-size: 11px;
            padding: 2px 8px;
            border-radius: 10px;
        }
        
        .chat-main {
            flex: 1;
            margin-left: 24px;
            display: flex;
            flex-direction: column;
            background: #222740;
            border-radius: 16px;
            overflow: hidden;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .chat-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            display: flex;
            align-items: center;
            gap: 14px;
        }
        
        .chat-header-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 2px solid rgba(0, 212, 255, 0.3);
        }
        
        .chat-header-info { flex: 1; }
        
        .chat-header-name {
            font-size: 18px;
            font-weight: 600;
        }
        
        .chat-header-status {
            font-size: 13px;
            color: #4ade80;
        }
        
        .chat-actions {
            display: flex;
            gap: 12px;
        }
        
        .action-btn {
            padding: 10px 20px;
            border-radius: 10px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .action-btn.primary {
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            color: #fff;
        }
        
        .action-btn.secondary {
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
        }
        
        .message-area {
            flex: 1;
            overflow-y: auto;
            padding: 24px;
        }
        
        .message-item {
            display: flex;
            gap: 12px;
            margin-bottom: 20px;
        }
        
        .message-item.msg-left { justify-content: flex-start; }
        .message-item.msg-right { justify-content: flex-end; }
        
        .msg-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            flex-shrink: 0;
            border: 2px solid rgba(0, 212, 255, 0.3);
        }
        
        .msg-content { max-width: 60%; }
        
        .msg-bubble {
            padding: 12px 16px;
            border-radius: 16px;
            font-size: 15px;
            line-height: 1.5;
        }
        
        .msg-left .msg-bubble {
            background: rgba(255, 255, 255, 0.1);
            border-bottom-left-radius: 4px;
        }
        
        .msg-right .msg-bubble {
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            border-bottom-right-radius: 4px;
        }
        
        .msg-time {
            font-size: 12px;
            color: #666;
            margin-top: 6px;
        }
        
        .msg-left .msg-time { text-align: left; }
        .msg-right .msg-time { text-align: right; }
        
        .input-area {
            padding: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            display: flex;
            gap: 12px;
        }
        
        .msg-input {
            flex: 1;
            padding: 14px 20px;
            background: #161a29;
            border: 1px solid #333;
            border-radius: 30px;
            color: #fff;
            font-size: 15px;
            outline: none;
        }
        
        .msg-input:focus { border-color: #00d4ff; }
        
        .send-btn {
            padding: 14px 32px;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            border: none;
            border-radius: 30px;
            color: #fff;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .send-btn:hover { transform: translateY(-2px); }
        
        .empty-state {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: #666;
        }
        
        .empty-icon { font-size: 64px; margin-bottom: 20px; }
        .empty-text { font-size: 18px; }
        
        .site-footer {
            background: #222740;
            padding: 24px 0;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }
        .footer-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 48px;
        }
        .footer-section h4 { font-size: 18px; margin-bottom: 16px; }
        .footer-section p, .footer-section a { color: #9ca3af; }
        .footer-section a { display: block; margin-bottom: 8px; text-decoration: none; }
        .footer-section a:hover { color: #00d4ff; }
        .footer-bottom {
            text-align: center;
            padding-top: 24px;
            margin-top: 32px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            color: #666;
        }
    </style>
</head>
<body>
    ''' + header_html + '''
    
    <div class="chat-container">
        <div class="chat-sidebar">
            <div class="sidebar-header">
                <div class="sidebar-title">Messages</div>
            </div>
            <div class="chat-list">
                ''' + chat_list_html + '''
                ''' + ('<div style="text-align:center;padding:40px;color:#666">No messages</div>' if not chat_list else '') + '''
            </div>
        </div>
        
        <div class="chat-main">
            ''' + current_chat_html + '''
        </div>
    </div>
    
    ''' + footer_html + '''
    
    <script>
        var currentChatId = ''' + str(current_chat_id) + ''';
        var selfAvatar = ''' + repr(self_avatar) + ''';
        var otherAvatar = ''' + repr(other_avatar) + ''';
        
        function selectChat(chatId, name, avatar) {
            currentChatId = chatId;
            location.href = '/chat?id=' + chatId;
        }
        
        function sendMessage() {
            var input = document.getElementById('msgInput');
            var content = input.value.trim();
            if (!content || !currentChatId) return;
            
            fetch('/api/v1/chat/message', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ chat_id: currentChatId, content: content })
            }).then(function(res) { return res.json(); }).then(function(data) {
                if (data.code == 200) {
                    input.value = '';
                    loadMessages();
                }
            });
        }
        
        function loadMessages() {
            if (!currentChatId) return;
            fetch('/api/v1/chat/messages?id=' + currentChatId).then(function(res) { return res.json(); }).then(function(data) {
                if (data.code == 200) {
                    var messageArea = document.getElementById('messageArea');
                    messageArea.innerHTML = '';
                    data.data.forEach(function(msg) {
                        var isSelf = msg.is_self;
                        var alignClass = isSelf ? 'msg-right' : 'msg-left';
                        var avatarUrl = isSelf ? selfAvatar : otherAvatar;
                        var html = '<div class="message-item ' + alignClass + '">' +
                            '<img src="' + avatarUrl + '" class="msg-avatar">' +
                            '<div class="msg-content">' +
                            '<div class="msg-bubble">' + msg.content + '</div>' +
                            '<div class="msg-time">' + msg.time + '</div>' +
                            '</div></div>';
                        messageArea.innerHTML += html;
                    });
                    messageArea.scrollTop = messageArea.scrollHeight;
                }
            });
        }
        
        setInterval(loadMessages, 5000);
    </script>
</body>
</html>
'''
