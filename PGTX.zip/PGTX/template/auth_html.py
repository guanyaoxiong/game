def get_login_page():
    return '''
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>登录 - GameMate</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Segoe UI', 'Microsoft YaHei', sans-serif; background: linear-gradient(135deg, #0f0f23 0%, #1a1a2e 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
            
            .login-container { width: 420px; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); border-radius: 24px; padding: 48px; box-shadow: 0 20px 60px rgba(0,0,0,0.5); border: 1px solid #2d2d44; position: relative; overflow: hidden; }
            .login-container::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #00d4ff, #ff6b6b, #00d4ff); }
            
            .logo { text-align: center; margin-bottom: 40px; }
            .logo h1 { font-size: 36px; color: #00d4ff; letter-spacing: 2px; }
            .logo p { font-size: 14px; color: #666; margin-top: 8px; }
            
            .form-group { margin-bottom: 24px; }
            .form-label { display: block; font-size: 14px; color: #888; margin-bottom: 12px; font-weight: 500; }
            .form-input { width: 100%; padding: 16px 20px; background: #0f0f23; border: 2px solid #2d2d44; border-radius: 12px; color: #fff; font-size: 16px; transition: all 0.3s; }
            .form-input:focus { border-color: #00d4ff; outline: none; box-shadow: 0 0 20px rgba(0,212,255,0.2); }
            .form-input::placeholder { color: #555; }
            
            .login-btn { width: 100%; padding: 16px; background: linear-gradient(135deg, #00d4ff, #0099cc); border: none; border-radius: 12px; color: #fff; font-size: 18px; font-weight: 600; cursor: pointer; transition: all 0.3s; letter-spacing: 1px; }
            .login-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,212,255,0.4); }
            
            .switch-link { text-align: center; margin-top: 32px; }
            .switch-link span { color: #666; }
            .switch-link a { color: #00d4ff; text-decoration: none; font-weight: 500; }
            .switch-link a:hover { text-decoration: underline; }
            
            .error-msg { color: #ff6b6b; text-align: center; margin-bottom: 20px; font-size: 14px; padding: 12px; background: rgba(255,107,107,0.1); border-radius: 8px; border: 1px solid rgba(255,107,107,0.3); }
            
            .features { margin-top: 32px; padding-top: 24px; border-top: 1px solid #2d2d44; }
            .feature-item { display: flex; align-items: center; gap: 12px; margin-bottom: 12px; color: #888; font-size: 14px; }
            .feature-icon { width: 24px; height: 24px; border-radius: 50%; background: linear-gradient(135deg, #00d4ff, #0099cc); display: flex; align-items: center; justify-content: center; font-size: 12px; color: #fff; }
            
            .back-link { position: absolute; top: 24px; left: 24px; color: #666; text-decoration: none; font-size: 14px; }
            .back-link:hover { color: #00d4ff; }
        </style>
    </head>
    <body>
        <div class="login-container">
            <a href="/" class="back-link">返回首页</a>
            
            <div class="logo">
                <h1>GameMate</h1>
                <p>AI智能陪玩推荐平台</p>
            </div>
            
            <div id="error-msg" class="error-msg" style="display:none"></div>
            
            <form id="login-form" onsubmit="submitLogin(event)">
                <div class="form-group">
                    <label class="form-label">用户名</label>
                    <input type="text" class="form-input" id="username" placeholder="请输入用户名" required>
                </div>
                <div class="form-group">
                    <label class="form-label">密码</label>
                    <input type="password" class="form-input" id="password" placeholder="请输入密码" required>
                </div>
                <button type="submit" class="login-btn">登录</button>
            </form>
            
            <div class="switch-link">
                <span>还没有账号?</span> <a href="/register">立即注册</a>
            </div>
            
            <div class="features">
                <div class="feature-item">
                    <div class="feature-icon">AI</div>
                    <span>AI智能匹配推荐</span>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">V</div>
                    <span>严格资质审核</span>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">S</div>
                    <span>安全交易保障</span>
                </div>
            </div>
        </div>
        
        <script>
            function submitLogin(e) {
                e.preventDefault();
                const username = document.getElementById('username').value;
                const password = document.getElementById('password').value;
                
                fetch('/api/v1/login', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ username, password })
                }).then(res => res.json()).then(data => {
                    if (data.code == 200) {
                        localStorage.setItem('token', data.data.token);
                        location.href = '/';
                    } else {
                        const errorMsg = document.getElementById('error-msg');
                        errorMsg.style.display = 'block';
                        errorMsg.innerText = data.msg;
                    }
                });
            }
        </script>
    </body>
    </html>
    '''

def get_register_page():
    return '''
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>注册 - GameMate</title>
        <style>
            * { margin: 0; padding: 0; box-sizing: border-box; }
            body { font-family: 'Segoe UI', 'Microsoft YaHei', sans-serif; background: linear-gradient(135deg, #0f0f23 0%, #1a1a2e 100%); min-height: 100vh; display: flex; align-items: center; justify-content: center; }
            
            .register-container { width: 520px; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); border-radius: 24px; padding: 48px; box-shadow: 0 20px 60px rgba(0,0,0,0.5); border: 1px solid #2d2d44; position: relative; overflow: hidden; }
            .register-container::before { content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px; background: linear-gradient(90deg, #00d4ff, #ff6b6b, #00d4ff); }
            
            .logo { text-align: center; margin-bottom: 32px; }
            .logo h1 { font-size: 36px; color: #00d4ff; letter-spacing: 2px; }
            .logo p { font-size: 14px; color: #666; margin-top: 8px; }
            
            .role-tabs { display: flex; gap: 16px; margin-bottom: 32px; }
            .role-tab { flex: 1; padding: 16px; text-align: center; border-radius: 12px; cursor: pointer; background: #0f0f23; color: #888; border: 2px solid #2d2d44; transition: all 0.3s; font-weight: 500; }
            .role-tab:hover { border-color: #00d4ff; }
            .role-tab.active { background: linear-gradient(135deg, #00d4ff, #0099cc); color: #fff; border-color: #00d4ff; }
            
            .form-group { margin-bottom: 20px; }
            .form-label { display: block; font-size: 14px; color: #888; margin-bottom: 12px; font-weight: 500; }
            .form-input, .form-select { width: 100%; padding: 16px 20px; background: #0f0f23; border: 2px solid #2d2d44; border-radius: 12px; color: #fff; font-size: 16px; transition: all 0.3s; }
            .form-input:focus, .form-select:focus { border-color: #00d4ff; outline: none; box-shadow: 0 0 20px rgba(0,212,255,0.2); }
            .form-input::placeholder { color: #555; }
            
            .register-btn { width: 100%; padding: 16px; background: linear-gradient(135deg, #00d4ff, #0099cc); border: none; border-radius: 12px; color: #fff; font-size: 18px; font-weight: 600; cursor: pointer; transition: all 0.3s; letter-spacing: 1px; margin-top: 8px; }
            .register-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,212,255,0.4); }
            
            .switch-link { text-align: center; margin-top: 24px; }
            .switch-link span { color: #666; }
            .switch-link a { color: #00d4ff; text-decoration: none; font-weight: 500; }
            
            .error-msg { color: #ff6b6b; text-align: center; margin-bottom: 20px; font-size: 14px; padding: 12px; background: rgba(255,107,107,0.1); border-radius: 8px; border: 1px solid rgba(255,107,107,0.3); }
            
            .partner-fields { display: none; margin-top: 24px; padding-top: 24px; border-top: 1px solid #2d2d44; }
            .partner-fields.show { display: block; }
            .partner-title { font-size: 16px; color: #00d4ff; margin-bottom: 20px; font-weight: 500; }
            
            .back-link { position: absolute; top: 24px; left: 24px; color: #666; text-decoration: none; font-size: 14px; }
            .back-link:hover { color: #00d4ff; }
            
            .form-row { display: flex; gap: 16px; }
            .form-row .form-group { flex: 1; }
        </style>
    </head>
    <body>
        <div class="register-container">
            <a href="/" class="back-link">返回首页</a>
            
            <div class="logo">
                <h1>GameMate</h1>
                <p>AI智能陪玩推荐平台</p>
            </div>
            
            <div id="error-msg" class="error-msg" style="display:none"></div>
            
            <div class="role-tabs">
                <div class="role-tab active" onclick="switchRole('player')">玩家注册</div>
                <div class="role-tab" onclick="switchRole('partner')">陪玩入驻</div>
            </div>
            
            <form id="register-form" onsubmit="submitRegister(event)">
                <input type="hidden" id="role" value="player">
                
                <div class="form-group">
                    <label class="form-label">用户名</label>
                    <input type="text" class="form-input" id="username" placeholder="请输入用户名" required>
                </div>
                <div class="form-group">
                    <label class="form-label">密码</label>
                    <input type="password" class="form-input" id="password" placeholder="请输入密码" required>
                </div>
                <div class="form-group">
                    <label class="form-label">手机号</label>
                    <input type="tel" class="form-input" id="phone" placeholder="请输入手机号" required>
                </div>
                
                <div class="partner-fields" id="partner-fields">
                    <div class="partner-title">陪玩资质信息</div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">擅长游戏</label>
                            <select class="form-select" id="game">
                                <option value="英雄联盟">英雄联盟</option>
                                <option value="王者荣耀">王者荣耀</option>
                                <option value="绝地求生">绝地求生</option>
                                <option value="CS2">CS2</option>
                                <option value="原神">原神</option>
                                <option value="和平精英">和平精英</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">声线类型</label>
                            <select class="form-select" id="voice">
                                <option value="萝莉音">萝莉音</option>
                                <option value="御姐音">御姐音</option>
                                <option value="少年音">少年音</option>
                                <option value="大叔音">大叔音</option>
                                <option value="磁性音">磁性音</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">游戏段位</label>
                            <input type="text" class="form-input" id="level" placeholder="如: 钻石I" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">时薪定价(元)</label>
                            <input type="number" class="form-input" id="price" placeholder="请输入时薪" required>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="register-btn">注册</button>
            </form>
            
            <div class="switch-link">
                <span>已有账号?</span> <a href="/login">立即登录</a>
            </div>
        </div>
        
        <script>
            function switchRole(role) {
                document.getElementById('role').value = role;
                document.querySelectorAll('.role-tab').forEach(tab => tab.classList.remove('active'));
                event.target.classList.add('active');
                const partnerFields = document.getElementById('partner-fields');
                if (role === 'partner') {
                    partnerFields.classList.add('show');
                } else {
                    partnerFields.classList.remove('show');
                }
            }
            
            function submitRegister(e) {
                e.preventDefault();
                const role = document.getElementById('role').value;
                const username = document.getElementById('username').value;
                const password = document.getElementById('password').value;
                const phone = document.getElementById('phone').value;
                
                const data = { username, password, phone };
                
                if (role === 'partner') {
                    data.game = document.getElementById('game').value;
                    data.level = document.getElementById('level').value;
                    data.price = parseFloat(document.getElementById('price').value);
                    data.voice = document.getElementById('voice').value;
                }
                
                const url = role === 'partner' ? '/api/v1/partner/register' : '/api/v1/player/register';
                
                fetch(url, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                }).then(res => res.json()).then(data => {
                    if (data.code == 200) {
                        alert(data.msg);
                        location.href = '/login';
                    } else {
                        const errorMsg = document.getElementById('error-msg');
                        errorMsg.style.display = 'block';
                        errorMsg.innerText = data.msg;
                    }
                });
            }
        </script>
    </body>
    </html>
    '''