def get_admin_page(statistics=None, pending_partners=None, pending_refunds=None):
    stats_html = ""
    if statistics:
        stats_html = f'''
        <div class="stats-grid">
            <div class="stat-item">
                <span class="stat-value">{statistics["player_count"]}</span>
                <span class="stat-label">玩家数量</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">{statistics["partner_count"]}</span>
                <span class="stat-label">陪玩数量</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">{statistics["order_count"]}</span>
                <span class="stat-label">订单总数</span>
            </div>
            <div class="stat-item">
                <span class="stat-value">¥{statistics["total_revenue"]}</span>
                <span class="stat-label">总收入</span>
            </div>
        </div>
        '''
    
    partners_html = ""
    if pending_partners:
        for p in pending_partners:
            partners_html += f'''
            <tr>
                <td>{p["username"]}</td>
                <td>{p["game"]}</td>
                <td>{p["level"]}</td>
                <td>¥{p["price"]}/小时</td>
                <td>{p["voice"]}</td>
                <td>{p["create_time"]}</td>
                <td>
                    <button onclick="auditPartner({p["partner_id"]}, true)">通过</button>
                    <button onclick="auditPartner({p["partner_id"]}, false)">驳回</button>
                </td>
            </tr>
            '''
    
    refunds_html = ""
    if pending_refunds:
        for r in pending_refunds:
            refunds_html += f'''
            <tr>
                <td>{r["order_id"]}</td>
                <td>{r["player_username"]}</td>
                <td>{r["partner_username"]}</td>
                <td>¥{r["total_price"]}</td>
                <td>{r["create_time"]}</td>
                <td>{r["refund_reason"]}</td>
                <td>
                    <button onclick="handleRefund({r["order_id"]}, true)">同意</button>
                    <button onclick="handleRefund({r["order_id"]}, false)">拒绝</button>
                </td>
            </tr>
            '''
    
    return f'''
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>管理员后台</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #161a29; color: #fff; }}
            
            .header {{ background: #222740; padding: 16px 32px; display: flex; justify-content: space-between; align-items: center; }}
            .header h1 {{ font-size: 24px; color: #007bff; }}
            .header a {{ color: #ccc; text-decoration: none; }}
            
            .main-content {{ display: flex; }}
            .sidebar {{ width: 240px; background: #222740; min-height: calc(100vh - 60px); padding: 20px; }}
            .menu-item {{ padding: 12px; border-radius: 8px; cursor: pointer; margin-bottom: 8px; }}
            .menu-item:hover, .menu-item.active {{ background: #007bff; }}
            
            .main-area {{ flex: 1; padding: 32px; }}
            .page-title {{ font-size: 24px; margin-bottom: 24px; }}
            
            .stats-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px; margin-bottom: 32px; }}
            .stat-item {{ background: #222740; border-radius: 12px; padding: 24px; text-align: center; }}
            .stat-value {{ display: block; font-size: 32px; color: #4ade80; font-weight: bold; }}
            .stat-label {{ font-size: 14px; color: #999; }}
            
            .section-card {{ background: #222740; border-radius: 12px; padding: 24px; margin-bottom: 24px; }}
            .section-title {{ font-size: 20px; margin-bottom: 20px; }}
            
            .data-table {{ width: 100%; border-collapse: collapse; }}
            .data-table th, .data-table td {{ padding: 12px; text-align: left; border-bottom: 1px solid #333; }}
            .data-table th {{ background: #161a29; }}
            .data-table button {{ padding: 6px 12px; border: none; border-radius: 6px; cursor: pointer; margin-right: 8px; }}
            .data-table button:nth-child(1) {{ background: #4ade80; color: #000; }}
            .data-table button:nth-child(2) {{ background: #ff6633; color: #fff; }}
        </style>
    </head>
    <body>
        <header class="header">
            <h1>🔧 管理员后台</h1>
            <a href="/">返回首页</a>
        </header>
        
        <div class="main-content">
            <aside class="sidebar">
                <div class="menu-item active" onclick="showTab('dashboard')">📊 数据看板</div>
                <div class="menu-item" onclick="showTab('audit')">✅ 资质审核</div>
                <div class="menu-item" onclick="showTab('refunds')">💰 退款处理</div>
                <div class="menu-item" onclick="showTab('complaints')">📢 投诉管理</div>
                <div class="menu-item" onclick="showTab('users')">👥 用户管理</div>
            </aside>
            
            <div class="main-area">
                <div id="tab-dashboard" class="tab-content">
                    <h2 class="page-title">数据看板</h2>
                    {stats_html}
                </div>
                
                <div id="tab-audit" class="tab-content" style="display:none">
                    <div class="section-card">
                        <h3 class="section-title">待审核陪玩</h3>
                        <table class="data-table">
                            <thead>
                                <tr><th>用户名</th><th>游戏</th><th>段位</th><th>价格</th><th>声线</th><th>申请时间</th><th>操作</th></tr>
                            </thead>
                            <tbody>{partners_html}</tbody>
                        </table>
                        {not pending_partners and "<p style='text-align:center;color:#666'>暂无待审核申请</p>" or ""}
                    </div>
                </div>
                
                <div id="tab-refunds" class="tab-content" style="display:none">
                    <div class="section-card">
                        <h3 class="section-title">待处理退款</h3>
                        <table class="data-table">
                            <thead>
                                <tr><th>订单号</th><th>玩家</th><th>陪玩</th><th>金额</th><th>下单时间</th><th>退款原因</th><th>操作</th></tr>
                            </thead>
                            <tbody>{refunds_html}</tbody>
                        </table>
                        {not pending_refunds and "<p style='text-align:center;color:#666'>暂无待处理退款</p>" or ""}
                    </div>
                </div>
                
                <div id="tab-complaints" class="tab-content" style="display:none">
                    <div class="section-card">
                        <h3 class="section-title">待处理投诉</h3>
                        <p style="text-align:center;color:#666">暂无待处理投诉</p>
                    </div>
                </div>
                
                <div id="tab-users" class="tab-content" style="display:none">
                    <div class="section-card">
                        <h3 class="section-title">用户列表</h3>
                        <p style="text-align:center;color:#666">用户管理功能开发中</p>
                    </div>
                </div>
            </div>
        </div>
        
        <script>
            function showTab(tab) {{
                document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
                event.target.classList.add('active');
                document.querySelectorAll('.tab-content').forEach(content => content.style.display = 'none');
                document.getElementById('tab-' + tab).style.display = 'block';
            }}
            
            function auditPartner(partner_id, pass) {{
                fetch('/api/v1/admin/audit', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ partner_id, pass }})
                }}).then(res => res.json()).then(data => {{
                    alert(data.msg);
                    if (data.code == 200) location.reload();
                }});
            }}
            
            function handleRefund(order_id, agree) {{
                fetch('/api/v1/admin/refund', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ order_id, agree }})
                }}).then(res => res.json()).then(data => {{
                    alert(data.msg);
                    if (data.code == 200) location.reload();
                }});
            }}
        </script>
    </body>
    </html>
    '''