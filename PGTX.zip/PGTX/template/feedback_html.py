def get_header(user_info, active_page=''):
    avatar_url = user_info.get('avatar', f"https://api.dicebear.com/7.x/avataaars/svg?seed={user_info.get('username', 'guest')}") if user_info else "https://api.dicebear.com/7.x/avataaars/svg?seed=guest"

    return f'''
    <header class="site-header">
        <div class="header-container">
            <a href="/" class="logo">
                <span class="logo-icon">🎮</span>
                <span class="logo-text">AI陪玩</span>
            </a>
            <nav class="main-nav">
                <a href="/" class="nav-item {"active" if active_page == "home" else ""}">首页</a>
                <a href="/partners" class="nav-item {"active" if active_page == "partners" else ""}">陪玩列表</a>
                <a href="/wish" class="nav-item {"active" if active_page == "wish" else ""}">心愿匹配</a>
                <a href="/feedback" class="nav-item {"active" if active_page == "feedback" else ""}">问题反馈</a>
            </nav>
            <div class="user-area">
                <img src="{avatar_url}" alt="头像" class="user-avatar" onerror="this.src='https://api.dicebear.com/7.x/avataaars/svg?seed=default'">
                <span class="user-name">{user_info.get('username', '游客') if user_info else '游客'}</span>
                <div class="user-dropdown">
                    <a href="/center" class="dropdown-item">个人中心</a>
                    <a href="/partner/workspace" class="dropdown-item">陪玩工作台</a>
                    <a href="/admin" class="dropdown-item">管理后台</a>
                </div>
            </div>
        </div>
    </header>
    '''

def get_footer():
    return '''
    <footer class="site-footer">
        <div class="footer-content">
            <div class="footer-section">
                <h4>关于我们</h4>
                <p>AI智能陪玩推荐平台 - 用Python原生代码打造的智能推荐系统</p>
            </div>
            <div class="footer-section">
                <h4>快速链接</h4>
                <a href="/">首页</a>
                <a href="/partners">陪玩列表</a>
                <a href="/wish">心愿匹配</a>
                <a href="/feedback">问题反馈</a>
            </div>
            <div class="footer-section">
                <h4>联系方式</h4>
                <p>📧 support@gameplaymate.com</p>
                <p>📞 400-888-8888</p>
            </div>
        </div>
        <div class="footer-bottom">
            <p>© 2024 AI陪玩推荐平台 | 纯Python零依赖开发</p>
        </div>
    </footer>
    '''

def get_feedback_page(user_info, feedback_list=None, success_msg=''):
    avatar_url = user_info.get('avatar', f"https://api.dicebear.com/7.x/avataaars/svg?seed={user_info.get('username', 'guest')}") if user_info else "https://api.dicebear.com/7.x/avataaars/svg?seed=guest"

    feedback_html = ''
    if feedback_list:
        for fb in feedback_list:
            status_class = 'resolved' if fb.get('status') == 'resolved' else 'pending'
            status_text = '已处理' if fb.get('status') == 'resolved' else '处理中'
            reply_html = ''
            if fb.get('reply'):
                reply_html = f'<div class="feedback-reply"><strong>官方回复：</strong>{fb.get("reply", "")}</div>'
            feedback_html += f'''
            <div class="feedback-item {status_class}">
                <div class="feedback-header">
                    <span class="feedback-type">{fb.get('type', '其他')}</span>
                    <span class="feedback-status">{status_text}</span>
                </div>
                <div class="feedback-content">{fb.get('content', '')}</div>
                <div class="feedback-meta">
                    <span>提交时间：{fb.get('create_time', '')}</span>
                    <span>订单号：{fb.get('order_id', '无')}</span>
                </div>
                {reply_html}
            </div>
            '''
    else:
        feedback_html = '<p class="no-feedback">暂无反馈记录</p>'

    return f'''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>问题反馈 - AI陪玩推荐平台</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, sans-serif; background: #0a0a14; color: #fff; min-height: 100vh; }}
        a {{ text-decoration: none; color: inherit; }}

        .site-header {{
            background: rgba(15, 15, 25, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            position: sticky;
            top: 0;
            z-index: 1000;
        }}
        .header-container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            height: 72px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        .logo {{
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .logo-icon {{ font-size: 36px; }}
        .logo-text {{
            font-size: 26px;
            font-weight: 700;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .main-nav {{ display: flex; gap: 8px; }}
        .nav-item {{
            padding: 10px 20px;
            color: #9ca3af;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }}
        .nav-item:hover {{ color: #00d4ff; background: rgba(0, 212, 255, 0.08); }}
        .nav-item.active {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}
        .user-area {{
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 16px;
            border-radius: 16px;
            cursor: pointer;
            position: relative;
            transition: all 0.3s ease;
        }}
        .user-area:hover {{ background: rgba(255, 255, 255, 0.05); }}
        .user-avatar {{
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid rgba(0, 212, 255, 0.5);
        }}
        .user-name {{ font-weight: 500; color: #fff; }}
        .user-dropdown {{
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: rgba(20, 20, 35, 0.98);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 8px;
            min-width: 180px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
        }}
        .user-area:hover .user-dropdown {{ opacity: 1; visibility: visible; transform: translateY(0); }}
        .dropdown-item {{
            display: block;
            padding: 12px 16px;
            color: #9ca3af;
            border-radius: 10px;
        }}
        .dropdown-item:hover {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}

        .feedback-container {{ max-width: 900px; margin: 40px auto; padding: 0 20px; }}
        .page-title {{
            font-size: 32px;
            font-weight: 700;
            text-align: center;
            margin-bottom: 40px;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .feedback-form-card {{
            background: rgba(30, 30, 50, 0.8);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 24px;
            padding: 40px;
            margin-bottom: 40px;
        }}
        .form-title {{
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .form-title::before {{
            content: '';
            width: 4px;
            height: 24px;
            background: linear-gradient(180deg, #00d4ff, #7c3aed);
            border-radius: 2px;
        }}
        .form-group {{ margin-bottom: 24px; }}
        .form-label {{ display: block; margin-bottom: 10px; color: #a0a0a0; font-weight: 500; }}
        .form-select, .form-input, .form-textarea {{
            width: 100%;
            padding: 16px 20px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            transition: all 0.3s ease;
        }}
        .form-select:focus, .form-input:focus, .form-textarea:focus {{
            outline: none;
            border-color: #00d4ff;
            background: rgba(0, 212, 255, 0.05);
        }}
        .form-textarea {{ min-height: 150px; resize: vertical; }}
        .form-select option {{ background: #1a1a2e; color: #fff; }}
        .submit-btn {{
            width: 100%;
            padding: 18px;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }}
        .submit-btn:hover {{ transform: translateY(-2px); box-shadow: 0 15px 40px rgba(0, 212, 255, 0.4); }}
        .success-message {{
            background: linear-gradient(135deg, rgba(34, 197, 94, 0.2), rgba(34, 197, 94, 0.1));
            border: 1px solid rgba(34, 197, 94, 0.3);
            border-radius: 12px;
            padding: 16px 20px;
            color: #22c55e;
            margin-bottom: 24px;
            text-align: center;
        }}
        .history-section {{
            background: rgba(30, 30, 50, 0.8);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 24px;
            padding: 40px;
        }}
        .history-title {{
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .history-title::before {{
            content: '';
            width: 4px;
            height: 24px;
            background: linear-gradient(180deg, #22c55e, #10b981);
            border-radius: 2px;
        }}
        .feedback-item {{
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 16px;
            transition: all 0.3s ease;
        }}
        .feedback-item:hover {{ border-color: rgba(0, 212, 255, 0.3); background: rgba(0, 212, 255, 0.03); }}
        .feedback-item.resolved {{ border-left: 4px solid #22c55e; }}
        .feedback-item.pending {{ border-left: 4px solid #f59e0b; }}
        .feedback-header {{ display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }}
        .feedback-type {{
            background: linear-gradient(135deg, rgba(124, 58, 237, 0.2), rgba(124, 58, 237, 0.1));
            color: #a78bfa;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
        }}
        .feedback-status {{ font-size: 14px; font-weight: 500; }}
        .resolved .feedback-status {{ color: #22c55e; }}
        .pending .feedback-status {{ color: #f59e0b; }}
        .feedback-content {{ color: #e0e0e0; line-height: 1.8; margin-bottom: 12px; }}
        .feedback-meta {{ display: flex; gap: 20px; color: #6b7280; font-size: 14px; }}
        .feedback-reply {{
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: #a0a0a0;
            line-height: 1.6;
        }}
        .no-feedback {{ text-align: center; color: #6b7280; padding: 40px; }}

        .site-footer {{
            background: rgba(15, 15, 25, 0.95);
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            margin-top: 80px;
            padding: 40px 20px;
        }}
        .footer-content {{
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
        }}
        .footer-section h4 {{ color: #fff; margin-bottom: 16px; font-size: 18px; }}
        .footer-section p, .footer-section a {{ color: #6b7280; line-height: 2; display: block; }}
        .footer-section a:hover {{ color: #00d4ff; }}
        .footer-bottom {{
            max-width: 1400px;
            margin: 40px auto 0;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            text-align: center;
            color: #6b7280;
        }}
    </style>
</head>
<body>
    {get_header(user_info, 'feedback')}

    <div class="feedback-container">
        <h1 class="page-title">问题反馈</h1>

        <div class="feedback-form-card">
            <div class="form-title">提交反馈</div>
            {'<div class="success-message">' + success_msg + '</div>' if success_msg else ''}
            <form id="feedbackForm">
                <div class="form-group">
                    <label class="form-label">反馈类型</label>
                    <select class="form-select" name="type" required>
                        <option value="">请选择反馈类型</option>
                        <option value="功能问题">功能问题</option>
                        <option value="订单问题">订单问题</option>
                        <option value="支付问题">支付问题</option>
                        <option value="陪玩投诉">陪玩投诉</option>
                        <option value="建议意见">建议意见</option>
                        <option value="其他问题">其他问题</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">关联订单（可选）</label>
                    <input type="number" class="form-input" name="order_id" placeholder="请输入订单号，无则留空">
                </div>
                <div class="form-group">
                    <label class="form-label">反馈内容</label>
                    <textarea class="form-textarea" name="content" placeholder="请详细描述您遇到的问题或您的建议..." required></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">联系方式（可选）</label>
                    <input type="text" class="form-input" name="contact" placeholder="手机号或邮箱，方便我们联系您">
                </div>
                <button type="submit" class="submit-btn">提交反馈</button>
            </form>
        </div>

        <div class="history-section">
            <div class="history-title">我的反馈记录</div>
            {feedback_html}
        </div>
    </div>

    {get_footer()}

    <script>
        document.getElementById('feedbackForm').addEventListener('submit', async function(e) {{
            e.preventDefault();
            const formData = new FormData(this);
            const data = Object.fromEntries(formData);

            if (data.order_id === '') data.order_id = 0;
            else data.order_id = parseInt(data.order_id);

            try {{
                const response = await fetch('/api/v1/feedback/submit', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify(data)
                }});
                const result = await response.json();
                if (result.code === 200) {{
                    alert('提交成功！');
                    window.location.reload();
                }} else {{
                    alert(result.msg || '提交失败');
                }}
            }} catch (error) {{
                alert('提交失败，请重试');
            }}
        }});
    </script>
</body>
</html>
    '''