from template.home_html import get_header, get_footer, get_partner_card

def get_partner_list_page(user_info=None, partners=None, games=None, voices=None, filters=None):
    game_options = ""
    if games:
        game_options = ''.join([f'<option value="{g}">{g}</option>' for g in games])
    
    voice_options = ""
    if voices:
        voice_options = ''.join([f'<option value="{v}">{v}</option>' for v in voices])
    
    partner_html = ""
    if partners:
        for p in partners:
            partner_html += get_partner_card(p)

    return f'''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>陪玩列表 - AI陪玩推荐平台</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, sans-serif; background: #0a0a14; color: #fff; min-height: 100vh; }}
        a {{ text-decoration: none; color: inherit; }}

        .site-header {{
            background: rgba(15, 15, 25, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            position: sticky;
            top: 0;
            z-index: 1000;
        }}
        .header-container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            height: 72px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        .logo {{ display: flex; align-items: center; gap: 10px; }}
        .logo-icon {{ font-size: 36px; }}
        .logo-text {{
            font-size: 26px;
            font-weight: 700;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .main-nav {{ display: flex; gap: 8px; }}
        .nav-item {{
            padding: 10px 20px;
            color: #9ca3af;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }}
        .nav-item:hover {{ color: #00d4ff; background: rgba(0, 212, 255, 0.08); }}
        .nav-item.active {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}
        .nav-right {{ display: flex; align-items: center; gap: 16px; }}
        .nav-link {{ padding: 8px 16px; color: #9ca3af; border-radius: 10px; }}
        .nav-link:hover {{ color: #00d4ff; }}
        .nav-link.register-btn {{ background: linear-gradient(135deg, #00d4ff, #7c3aed); color: #fff; }}
        .nav-link.balance {{ color: #4ade80; font-weight: 600; }}
        .user-area {{
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 16px;
            border-radius: 16px;
            cursor: pointer;
            position: relative;
        }}
        .user-avatar {{ width: 40px; height: 40px; border-radius: 50%; border: 2px solid rgba(0, 212, 255, 0.5); }}
        .user-name {{ font-weight: 500; color: #fff; }}
        .user-dropdown {{
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: rgba(20, 20, 35, 0.98);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 8px;
            min-width: 180px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
        }}
        .user-area:hover .user-dropdown {{ opacity: 1; visibility: visible; transform: translateY(0); }}
        .dropdown-item {{
            display: block;
            padding: 12px 16px;
            color: #9ca3af;
            border-radius: 10px;
        }}
        .dropdown-item:hover {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}

        .main-container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 24px;
        }}

        .page-title {{
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 32px;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}

        .main-content {{
            display: flex;
            gap: 24px;
        }}

        .sidebar {{
            width: 280px;
            flex-shrink: 0;
        }}

        .filter-box {{
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 20px;
            padding: 28px;
            border: 1px solid rgba(255, 255, 255, 0.06);
        }}

        .filter-title {{
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .filter-title::before {{
            content: '';
            width: 4px;
            height: 20px;
            background: linear-gradient(180deg, #00d4ff, #7c3aed);
            border-radius: 2px;
        }}

        .filter-group {{
            margin-bottom: 20px;
        }}

        .filter-label {{
            display: block;
            font-size: 14px;
            color: #9ca3af;
            margin-bottom: 8px;
        }}

        .filter-select, .filter-input {{
            width: 100%;
            padding: 12px 16px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
        }}

        .filter-select:focus, .filter-input:focus {{
            outline: none;
            border-color: #00d4ff;
            background: rgba(0, 212, 255, 0.05);
        }}

        .filter-select option {{ background: #1a1a2e; color: #fff; }}

        .filter-row {{
            display: flex;
            gap: 8px;
        }}

        .filter-row .filter-input {{
            flex: 1;
        }}

        .filter-btn {{
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }}

        .filter-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(0, 212, 255, 0.3);
        }}

        .main-area {{
            flex: 1;
        }}

        .sort-bar {{
            display: flex;
            gap: 12px;
            margin-bottom: 24px;
        }}

        .sort-btn {{
            padding: 10px 24px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #9ca3af;
            font-size: 15px;
            cursor: pointer;
            transition: all 0.3s ease;
        }}

        .sort-btn:hover {{
            background: rgba(0, 212, 255, 0.1);
            color: #00d4ff;
        }}

        .sort-btn.active {{
            background: linear-gradient(135deg, rgba(0, 212, 255, 0.2), rgba(124, 58, 237, 0.2));
            color: #00d4ff;
            border-color: rgba(0, 212, 255, 0.3);
        }}

        .partner-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 24px;
        }}

        .partner-card {{
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 20px;
            padding: 28px;
            cursor: pointer;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(255, 255, 255, 0.06);
            position: relative;
            overflow: hidden;
        }}
        .partner-card::before {{
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, #00d4ff, #7c3aed);
            opacity: 0;
            transition: opacity 0.3s ease;
        }}
        .partner-card:hover {{
            transform: translateY(-8px);
            box-shadow: 0 25px 50px rgba(0, 212, 255, 0.15);
            border-color: rgba(0, 212, 255, 0.3);
        }}
        .partner-card:hover::before {{ opacity: 1; }}

        .match-tag {{
            position: absolute;
            top: 16px;
            right: 16px;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
        }}
        .match-tag.gold {{ background: linear-gradient(135deg, #fbbf24, #f59e0b); color: #000; }}
        .match-tag.blue {{ background: linear-gradient(135deg, #00d4ff, #0891b2); color: #fff; }}
        .match-tag.gray {{ background: rgba(255, 255, 255, 0.1); color: #9ca3af; }}

        .card-header {{
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 20px;
        }}
        .partner-avatar {{
            width: 64px;
            height: 64px;
            border-radius: 50%;
            border: 3px solid rgba(0, 212, 255, 0.3);
        }}
        .status-indicator {{
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
        }}
        .status-indicator.online {{ background: rgba(74, 222, 128, 0.15); color: #4ade80; }}
        .status-indicator.offline {{ background: rgba(255, 255, 255, 0.1); color: #6b7280; }}
        .status-dot {{ width: 8px; height: 8px; border-radius: 50%; }}
        .status-indicator.online .status-dot {{ background: #4ade80; animation: pulse 2s infinite; }}
        .status-indicator.offline .status-dot {{ background: #6b7280; }}
        @keyframes pulse {{ 0%, 100% {{ opacity: 1; transform: scale(1); }} 50% {{ opacity: 0.6; transform: scale(1.2); }} }}

        .partner-name {{ font-size: 20px; font-weight: 600; margin-bottom: 12px; }}
        .partner-tags {{
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin-bottom: 16px;
        }}
        .partner-tag {{
            padding: 4px 12px;
            background: rgba(0, 212, 255, 0.1);
            border-radius: 12px;
            font-size: 12px;
            color: #00d4ff;
        }}
        .partner-info {{
            display: flex;
            flex-direction: column;
            gap: 10px;
        }}
        .info-item {{ font-size: 14px; color: #9ca3af; }}

        .card-footer {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
        }}
        .price-section {{ display: flex; align-items: baseline; gap: 4px; }}
        .price-label {{ font-size: 13px; color: #6b7280; }}
        .price-value {{ font-size: 28px; font-weight: 700; color: #f472b6; }}
        .price-unit {{ font-size: 14px; color: #f472b6; }}
        .rating-text {{ font-size: 15px; color: #fbbf24; }}

        .card-stats {{
            display: flex;
            justify-content: space-around;
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
        }}
        .stat-item {{ text-align: center; }}
        .stat-value {{ font-size: 18px; font-weight: 600; color: #00d4ff; }}
        .stat-label {{ font-size: 12px; color: #6b7280; display: block; margin-top: 4px; }}

        .site-footer {{
            background: rgba(15, 15, 25, 0.95);
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            padding: 60px 24px 30px;
            margin-top: 80px;
        }}
        .footer-content {{
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
        }}
        .footer-section h4 {{ font-size: 18px; color: #fff; margin-bottom: 16px; }}
        .footer-section p, .footer-section a {{
            color: #6b7280;
            font-size: 14px;
            line-height: 2;
            display: block;
        }}
        .footer-section a:hover {{ color: #00d4ff; }}
        .footer-bottom {{
            max-width: 1400px;
            margin: 40px auto 0;
            padding-top: 24px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
            text-align: center;
            color: #6b7280;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    {get_header(user_info, 'partners')}
    
    <div class="main-container">
        <h1 class="page-title">陪玩列表</h1>
        
        <div class="main-content">
            <aside class="sidebar">
                <div class="filter-box">
                    <h3 class="filter-title">筛选条件</h3>
                    <div class="filter-group">
                        <label class="filter-label">游戏品类</label>
                        <select class="filter-select" id="game">
                            <option value="">全部</option>
                            {game_options}
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">声线类型</label>
                        <select class="filter-select" id="voice">
                            <option value="">全部</option>
                            {voice_options}
                        </select>
                    </div>
                    <div class="filter-group">
                        <label class="filter-label">价格区间</label>
                        <div class="filter-row">
                            <input type="number" class="filter-input" id="price_min" placeholder="最低">
                            <input type="number" class="filter-input" id="price_max" placeholder="最高">
                        </div>
                    </div>
                    <button class="filter-btn" onclick="filterPartners()">筛选</button>
                </div>
            </aside>
            
            <div class="main-area">
                <div class="sort-bar">
                    <button class="sort-btn active" onclick="sortPartners('match')">AI匹配度</button>
                    <button class="sort-btn" onclick="sortPartners('price')">价格最低</button>
                    <button class="sort-btn" onclick="sortPartners('good_rate')">好评最高</button>
                </div>
                <div class="partner-grid">{partner_html}</div>
            </div>
        </div>
    </div>
    
    {get_footer()}
    
    <script>
        function filterPartners() {{
            const game = document.getElementById('game').value;
            const voice = document.getElementById('voice').value;
            const price_min = document.getElementById('price_min').value;
            const price_max = document.getElementById('price_max').value;
            let url = '/partners?';
            if (game) url += 'game=' + encodeURIComponent(game) + '&';
            if (voice) url += 'voice=' + encodeURIComponent(voice) + '&';
            if (price_min) url += 'price_min=' + price_min + '&';
            if (price_max) url += 'price_max=' + price_max + '&';
            location.href = url;
        }}
        function sortPartners(sort) {{
            const urlParams = new URLSearchParams(window.location.search);
            urlParams.set('sort', sort);
            location.href = '/partners?' + urlParams.toString();
        }}
    </script>
</body>
</html>
    '''

def get_partner_detail_page(user_info=None, partner=None, similar_partners=None, is_favorite=False):
    if not partner:
        return "<h1>陪玩不存在</h1>"
    
    evaluates_html = ""
    if partner.get("evaluates"):
        for e in partner["evaluates"]:
            stars = "★" * e.get("rating", 0) + "☆" * (5 - e.get("rating", 0))
            evaluates_html += f'''
            <div class="evaluate-item">
                <div class="evaluate-header">
                    <span class="evaluate-user">{e.get("username", "匿名")}</span>
                    <span class="evaluate-stars">{stars}</span>
                </div>
                <p class="evaluate-content">{e.get("content", "")}</p>
                <span class="evaluate-time">{e.get("create_time", "")}</span>
            </div>
            '''
    
    similar_html = ""
    if similar_partners:
        for p in similar_partners:
            similar_html += f'''
            <div class="similar-item" onclick="location.href='/partner/{p["partner_id"]}'">
                <img src="{p.get("avatar", f"https://api.dicebear.com/7.x/avataaars/svg?seed={p.get("username", "user")}")}" class="similar-avatar" alt="头像">
                <div class="similar-info">
                    <span class="similar-name">{p["username"]}</span>
                    <span class="similar-game">{p["game"]}</span>
                </div>
                <span class="similar-match">{p.get("match_rate", 0)}%</span>
            </div>
            '''
    
    favorite_btn = f'<button class="action-btn" onclick="toggleFavorite({partner["partner_id"]})">❤ 收藏</button>'
    if is_favorite:
        favorite_btn = f'<button class="action-btn" onclick="toggleFavorite({partner["partner_id"]})">💔 取消收藏</button>'

    avatar_url = partner.get("avatar", f"https://api.dicebear.com/7.x/avataaars/svg?seed={partner.get('username', 'user')}")
    
    return f'''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{partner["username"]} - 陪玩详情</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, sans-serif; background: #0a0a14; color: #fff; min-height: 100vh; }}
        a {{ text-decoration: none; color: inherit; }}

        .site-header {{
            background: rgba(15, 15, 25, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            position: sticky;
            top: 0;
            z-index: 1000;
        }}
        .header-container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            height: 72px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        .logo {{ display: flex; align-items: center; gap: 10px; }}
        .logo-icon {{ font-size: 36px; }}
        .logo-text {{
            font-size: 26px;
            font-weight: 700;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .main-nav {{ display: flex; gap: 8px; }}
        .nav-item {{
            padding: 10px 20px;
            color: #9ca3af;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }}
        .nav-item:hover {{ color: #00d4ff; background: rgba(0, 212, 255, 0.08); }}
        .nav-item.active {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}
        .nav-right {{ display: flex; align-items: center; gap: 16px; }}
        .nav-link {{ padding: 8px 16px; color: #9ca3af; border-radius: 10px; }}
        .nav-link:hover {{ color: #00d4ff; }}
        .nav-link.register-btn {{ background: linear-gradient(135deg, #00d4ff, #7c3aed); color: #fff; }}
        .nav-link.balance {{ color: #4ade80; font-weight: 600; }}
        .user-area {{
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 16px;
            border-radius: 16px;
            cursor: pointer;
            position: relative;
        }}
        .user-avatar {{ width: 40px; height: 40px; border-radius: 50%; border: 2px solid rgba(0, 212, 255, 0.5); }}
        .user-name {{ font-weight: 500; color: #fff; }}
        .user-dropdown {{
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: rgba(20, 20, 35, 0.98);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 8px;
            min-width: 180px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
        }}
        .user-area:hover .user-dropdown {{ opacity: 1; visibility: visible; transform: translateY(0); }}
        .dropdown-item {{
            display: block;
            padding: 12px 16px;
            color: #9ca3af;
            border-radius: 10px;
        }}
        .dropdown-item:hover {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}

        .main-container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 24px;
        }}

        .main-content {{
            display: flex;
            gap: 32px;
        }}

        .main-left {{ flex: 1; }}

        .detail-card {{
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 24px;
            padding: 40px;
            border: 1px solid rgba(255, 255, 255, 0.06);
        }}

        .detail-header {{
            display: flex;
            align-items: center;
            gap: 24px;
            margin-bottom: 32px;
        }}

        .avatar {{
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 4px solid rgba(0, 212, 255, 0.3);
        }}

        .status-dot {{
            width: 24px;
            height: 24px;
            border-radius: 50%;
            border: 4px solid rgba(26, 26, 46, 1);
        }}
        .status-dot.online {{ background: #4ade80; }}
        .status-dot.offline {{ background: #6b7280; }}

        .info-header {{ flex: 1; }}
        .partner-name {{ font-size: 32px; font-weight: 700; margin-bottom: 8px; }}
        .partner-status {{
            font-size: 14px;
            color: {'#4ade80' if partner["status"] == 'online' else '#6b7280'};
        }}

        .info-grid {{
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 24px;
            margin-bottom: 32px;
        }}

        .info-item {{
            background: rgba(255, 255, 255, 0.03);
            padding: 20px;
            border-radius: 16px;
            text-align: center;
        }}
        .info-item strong {{
            display: block;
            font-size: 24px;
            font-weight: 700;
            color: #00d4ff;
            margin-bottom: 4px;
        }}
        .info-item span {{
            font-size: 14px;
            color: #9ca3af;
        }}

        .intro-section {{ margin-top: 32px; }}
        .intro-title {{
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .intro-title::before {{
            content: '';
            width: 4px;
            height: 20px;
            background: linear-gradient(180deg, #00d4ff, #7c3aed);
            border-radius: 2px;
        }}
        .intro-content {{
            color: #9ca3af;
            line-height: 1.8;
            font-size: 16px;
        }}

        .action-bar {{
            display: flex;
            gap: 16px;
            margin-top: 32px;
        }}
        .action-btn {{
            padding: 14px 32px;
            border: none;
            border-radius: 12px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: all 0.3s ease;
        }}
        .action-btn:nth-child(1) {{
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            color: #fff;
        }}
        .action-btn:nth-child(2) {{
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }}
        .action-btn:hover {{ transform: translateY(-2px); }}

        .order-panel {{
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 24px;
            padding: 32px;
            position: sticky;
            top: 100px;
            border: 1px solid rgba(255, 255, 255, 0.06);
        }}

        .panel-title {{
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 24px;
        }}

        .price-info {{
            font-size: 40px;
            color: #f472b6;
            font-weight: 700;
            margin-bottom: 24px;
        }}
        .price-info span {{
            font-size: 16px;
            color: #9ca3af;
            font-weight: normal;
        }}

        .order-form {{
            display: flex;
            flex-direction: column;
            gap: 20px;
        }}

        .form-group {{
            display: flex;
            flex-direction: column;
        }}

        .form-label {{
            font-size: 14px;
            color: #9ca3af;
            margin-bottom: 8px;
        }}

        .form-input {{
            padding: 14px 16px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
        }}

        .form-input:focus {{
            outline: none;
            border-color: #00d4ff;
            background: rgba(0, 212, 255, 0.05);
        }}

        .order-btn {{
            padding: 18px;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 18px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }}

        .order-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 15px 40px rgba(0, 212, 255, 0.4);
        }}

        .evaluate-section, .similar-section {{
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 24px;
            padding: 32px;
            margin-top: 24px;
            border: 1px solid rgba(255, 255, 255, 0.06);
        }}

        .evaluate-title, .similar-title {{
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .evaluate-title::before, .similar-title::before {{
            content: '';
            width: 4px;
            height: 20px;
            background: linear-gradient(180deg, #00d4ff, #7c3aed);
            border-radius: 2px;
        }}

        .evaluate-item {{
            padding: 20px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 16px;
            margin-bottom: 16px;
        }}

        .evaluate-header {{
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
        }}

        .evaluate-user {{
            font-weight: 600;
            color: #fff;
        }}

        .evaluate-stars {{
            color: #fbbf24;
            font-size: 18px;
        }}

        .evaluate-content {{
            color: #9ca3af;
            line-height: 1.6;
            margin-bottom: 8px;
        }}

        .evaluate-time {{
            font-size: 12px;
            color: #6b7280;
        }}

        .similar-item {{
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 16px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 16px;
            margin-bottom: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
        }}

        .similar-item:hover {{
            background: rgba(0, 212, 255, 0.05);
            border-color: rgba(0, 212, 255, 0.2);
        }}

        .similar-avatar {{
            width: 56px;
            height: 56px;
            border-radius: 50%;
            border: 2px solid rgba(0, 212, 255, 0.3);
        }}

        .similar-info {{ flex: 1; }}

        .similar-name {{
            display: block;
            font-weight: 600;
            color: #fff;
        }}

        .similar-game {{
            font-size: 14px;
            color: #9ca3af;
        }}

        .similar-match {{
            color: #fbbf24;
            font-weight: 700;
            font-size: 18px;
        }}

        .site-footer {{
            background: rgba(15, 15, 25, 0.95);
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            padding: 60px 24px 30px;
            margin-top: 80px;
        }}
        .footer-content {{
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
        }}
        .footer-section h4 {{ font-size: 18px; color: #fff; margin-bottom: 16px; }}
        .footer-section p, .footer-section a {{
            color: #6b7280;
            font-size: 14px;
            line-height: 2;
            display: block;
        }}
        .footer-section a:hover {{ color: #00d4ff; }}
        .footer-bottom {{
            max-width: 1400px;
            margin: 40px auto 0;
            padding-top: 24px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
            text-align: center;
            color: #6b7280;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    {get_header(user_info)}
    
    <div class="main-container">
        <div class="main-content">
            <div class="main-left">
                <div class="detail-card">
                    <div class="detail-header">
                        <img src="{avatar_url}" class="avatar" alt="头像">
                        <div class="status-dot {'online' if partner["status"] == 'online' else 'offline'}"></div>
                        <div class="info-header">
                            <h1 class="partner-name">{partner["username"]}</h1>
                            <span class="partner-status">{'在线' if partner["status"] == 'online' else '离线'}</span>
                        </div>
                    </div>
                    
                    <div class="info-grid">
                        <div class="info-item"><strong>🎮 {partner["game"]}</strong><span>游戏</span></div>
                        <div class="info-item"><strong>🏆 {partner["level"]}</strong><span>段位</span></div>
                        <div class="info-item"><strong>🎤 {partner["voice"]}</strong><span>声线</span></div>
                        <div class="info-item"><strong>⭐ {int(partner["good_rate"]*100)}%</strong><span>好评率</span></div>
                        <div class="info-item"><strong>📊 {partner["order_count"]}</strong><span>接单量</span></div>
                        <div class="info-item"><strong>⏱️ {partner["hour_count"]}h</strong><span>服务时长</span></div>
                    </div>
                    
                    <div class="intro-section">
                        <h3 class="intro-title">个人介绍</h3>
                        <p class="intro-content">{partner["introduction"] or "暂无介绍"}</p>
                    </div>
                    
                    <div class="action-bar">
                        {favorite_btn}
                        <button class="action-btn" onclick="openChat()">💬 私信</button>
                    </div>
                </div>
                
                <div class="evaluate-section">
                    <h3 class="evaluate-title">用户评价</h3>
                    {evaluates_html}
                </div>
                
                <div class="similar-section">
                    <h3 class="similar-title">相似推荐</h3>
                    {similar_html}
                </div>
            </div>
            
            <div class="main-right" style="width: 360px; flex-shrink: 0;">
                <div class="order-panel">
                    <h3 class="panel-title">预约下单</h3>
                    <div class="price-info">¥{partner["price"]}<span>/小时</span></div>
                    <form class="order-form" onsubmit="submitOrder(event)">
                        <input type="hidden" id="partner_id" value="{partner["partner_id"]}">
                        <input type="hidden" id="game" value="{partner["game"]}">
                        <input type="hidden" id="price" value="{partner["price"]}">
                        <div class="form-group">
                            <label class="form-label">服务时长（小时）</label>
                            <input type="number" class="form-input" id="hours" value="1" min="1" max="24" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">总金额</label>
                            <input type="text" class="form-input" id="total_price" readonly>
                        </div>
                        <button type="submit" class="order-btn">立即下单</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    {get_footer()}
    
    <script>
        const price = parseInt(document.getElementById('price').value);
        document.getElementById('hours').addEventListener('input', function() {{
            document.getElementById('total_price').value = '¥' + (this.value * price);
        }});
        document.getElementById('total_price').value = '¥' + price;
        
        function submitOrder(e) {{
            e.preventDefault();
            const hours = document.getElementById('hours').value;
            const partner_id = document.getElementById('partner_id').value;
            const game = document.getElementById('game').value;
            const total_price = hours * price;
            
            fetch('/api/v1/order/create', {{
                method: 'POST',
                headers: {{ 'Content-Type': 'application/json' }},
                body: JSON.stringify({{ partner_id, hours, game, total_price }})
            }}).then(res => res.json()).then(data => {{
                if (data.code == 200) alert('下单成功!');
                else alert(data.msg);
            }});
        }}
        
        function toggleFavorite(partner_id) {{
            fetch('/api/v1/player/favorite', {{
                method: 'POST',
                headers: {{ 'Content-Type': 'application/json' }},
                body: JSON.stringify({{ partner_id }})
            }}).then(res => res.json()).then(data => {{
                alert(data.msg);
                location.reload();
            }});
        }}
        
        function openChat() {{
            alert('聊天功能开发中');
        }}
    </script>
</body>
</html>
    '''