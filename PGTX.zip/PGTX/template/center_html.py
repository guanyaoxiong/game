from template.home_html import get_header, get_footer

def get_center_page(user_info=None, orders=None, favorites=None, revenue=None):
    if not user_info:
        return "<h1>请先登录</h1>"
    
    role = user_info.get("role", "player")
    
    orders_html = ""
    if orders:
        status_map = {"pending": "待支付", "paid": "待开始", "in_progress": "进行中", "completed": "已完成", "rated": "已评价", "refund_pending": "退款中", "refunded": "已退款"}
        for o in orders:
            orders_html += f'''
            <div class="order-item">
                <div class="order-header">
                    <span class="order-id">订单号: {o["order_id"]}</span>
                    <span class="order-status {o["status"]}">{status_map.get(o["status"], o["status"])}</span>
                </div>
                <div class="order-body">
                    <span class="order-game">🎮 {o["game"]}</span>
                    <span class="order-hours">时长: {o["hours"]}小时</span>
                    <span class="order-price">¥{o["total_price"]}</span>
                </div>
                <div class="order-footer">
                    <span class="order-time">{o["create_time"]}</span>
                    <div class="order-actions">
                        {o["status"] == "paid" and f'<button onclick="startOrder({o["order_id"]})">开始服务</button>' or ""}
                        {o["status"] == "in_progress" and f'<button onclick="completeOrder({o["order_id"]})">完成服务</button>' or ""}
                        {o["status"] == "completed" and f'<button onclick="rateOrder({o["order_id"]})">评价</button>' or ""}
                        {o["status"] == "paid" and f'<button onclick="applyRefund({o["order_id"]})">申请退款</button>' or ""}
                    </div>
                </div>
            </div>
            '''
    
    favorites_html = ""
    if favorites:
        for f in favorites:
            favorites_html += f'''
            <div class="favorite-item">
                <div class="favorite-avatar">{f["username"][0]}</div>
                <div class="favorite-info">
                    <span class="favorite-name">{f["username"]}</span>
                    <span class="favorite-game">{f["game"]} - {f["level"]}</span>
                </div>
                <span class="favorite-price">¥{f["price"]}/小时</span>
                <button class="favorite-btn" onclick="location.href='/partner/{f["partner_id"]}'">查看</button>
            </div>
            '''
    
    revenue_html = ""
    if revenue:
        revenue_html = f'''
        <div class="revenue-card">
            <h3>收益统计</h3>
            <div class="revenue-row">
                <div class="revenue-item">
                    <span class="revenue-value">¥{revenue["today_revenue"]}</span>
                    <span class="revenue-label">今日收益</span>
                </div>
                <div class="revenue-item">
                    <span class="revenue-value">{revenue["today_orders"]}</span>
                    <span class="revenue-label">今日接单</span>
                </div>
                <div class="revenue-item">
                    <span class="revenue-value">¥{revenue["month_revenue"]}</span>
                    <span class="revenue-label">本月收益</span>
                </div>
                <div class="revenue-item">
                    <span class="revenue-value">{revenue["total_orders"]}</span>
                    <span class="revenue-label">总接单量</span>
                </div>
            </div>
            <div class="revenue-actions">
                <button onclick="applyWithdraw()">提现</button>
            </div>
        </div>
        '''
    
    return f'''
    <!DOCTYPE html>
    <html lang="zh-CN">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>个人中心</title>
        <style>
            * {{ margin: 0; padding: 0; box-sizing: border-box; }}
            body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #161a29; color: #fff; }}
            .container {{ max-width: 1200px; margin: 0 auto; padding: 0 20px; }}
            
            .header {{ background: linear-gradient(135deg, #222740 0%, #161a29 100%); padding: 16px 0; position: sticky; top: 0; z-index: 100; }}
            .header .container {{ display: flex; justify-content: space-between; align-items: center; }}
            .logo h1 {{ font-size: 24px; }}
            .logo a {{ color: #007bff; text-decoration: none; }}
            .nav {{ display: flex; gap: 24px; align-items: center; }}
            .nav-link {{ color: #ccc; text-decoration: none; font-size: 16px; }}
            .nav-link:hover, .nav-link.active {{ color: #007bff; }}
            
            .main-content {{ display: flex; gap: 24px; padding: 32px 0; }}
            .sidebar {{ width: 280px; flex-shrink: 0; }}
            .profile-card {{ background: #222740; border-radius: 12px; padding: 24px; text-align: center; }}
            .profile-avatar {{ width: 80px; height: 80px; border-radius: 50%; background: linear-gradient(135deg, #007bff, #8040ff); display: flex; align-items: center; justify-content: center; font-size: 32px; margin: 0 auto 16px; }}
            .profile-name {{ font-size: 20px; margin-bottom: 8px; }}
            .profile-role {{ font-size: 14px; color: #999; }}
            .balance-info {{ margin-top: 16px; padding-top: 16px; border-top: 1px solid #333; }}
            .balance-label {{ font-size: 14px; color: #999; }}
            .balance-value {{ font-size: 28px; color: #4ade80; font-weight: bold; }}
            
            .menu-list {{ background: #222740; border-radius: 12px; padding: 16px; margin-top: 16px; }}
            .menu-item {{ padding: 12px; border-radius: 8px; cursor: pointer; margin-bottom: 8px; }}
            .menu-item:hover, .menu-item.active {{ background: #007bff; }}
            
            .main-area {{ flex: 1; }}
            .section-card {{ background: #222740; border-radius: 12px; padding: 24px; margin-bottom: 24px; }}
            .section-title {{ font-size: 20px; margin-bottom: 20px; }}
            
            .order-item {{ padding: 16px; background: #161a29; border-radius: 8px; margin-bottom: 12px; }}
            .order-header {{ display: flex; justify-content: space-between; margin-bottom: 8px; }}
            .order-id {{ font-size: 14px; }}
            .order-status {{ font-size: 14px; padding: 4px 12px; border-radius: 12px; }}
            .order-status.paid {{ background: #ffd700; color: #000; }}
            .order-status.in_progress {{ background: #007bff; }}
            .order-status.completed {{ background: #4ade80; color: #000; }}
            .order-status.rated {{ background: #8040ff; }}
            .order-status.refund_pending {{ background: #ff6633; }}
            .order-body {{ display: flex; gap: 24px; margin-bottom: 8px; }}
            .order-game, .order-hours, .order-price {{ font-size: 14px; }}
            .order-price {{ color: #ff6633; }}
            .order-footer {{ display: flex; justify-content: space-between; }}
            .order-time {{ font-size: 12px; color: #666; }}
            .order-actions button {{ padding: 6px 12px; background: #007bff; border: none; border-radius: 6px; color: #fff; cursor: pointer; margin-left: 8px; }}
            
            .favorite-item {{ display: flex; align-items: center; gap: 12px; padding: 12px; background: #161a29; border-radius: 8px; margin-bottom: 8px; }}
            .favorite-avatar {{ width: 48px; height: 48px; border-radius: 50%; background: linear-gradient(135deg, #007bff, #8040ff); display: flex; align-items: center; justify-content: center; font-size: 18px; }}
            .favorite-info {{ flex: 1; }}
            .favorite-name {{ display: block; }}
            .favorite-game {{ font-size: 12px; color: #999; }}
            .favorite-price {{ color: #ff6633; }}
            .favorite-btn {{ padding: 6px 12px; background: #007bff; border: none; border-radius: 6px; color: #fff; cursor: pointer; }}
            
            .revenue-card {{ background: #222740; border-radius: 12px; padding: 24px; }}
            .revenue-card h3 {{ font-size: 20px; margin-bottom: 20px; }}
            .revenue-row {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; }}
            .revenue-item {{ text-align: center; padding: 16px; background: #161a29; border-radius: 8px; }}
            .revenue-value {{ display: block; font-size: 24px; color: #4ade80; font-weight: bold; }}
            .revenue-label {{ font-size: 12px; color: #999; }}
            .revenue-actions {{ margin-top: 20px; }}
            .revenue-actions button {{ padding: 10px 20px; background: #007bff; border: none; border-radius: 8px; color: #fff; cursor: pointer; }}
            
            .recharge-btn {{ padding: 12px 24px; background: #4ade80; color: #000; border: none; border-radius: 8px; cursor: pointer; font-size: 16px; }}
            
            .footer {{ background: #222740; padding: 24px 0; text-align: center; color: #666; margin-top: 40px; }}
        </style>
    </head>
    <body>
        {get_header(user_info)}
        
        <div class="container">
            <div class="main-content">
                <aside class="sidebar">
                    <div class="profile-card">
                        <div class="profile-avatar">{user_info["username"][0]}</div>
                        <div class="profile-name">{user_info["username"]}</div>
                        <div class="profile-role">{"玩家" if role == "player" else "陪玩师"}</div>
                        <div class="balance-info">
                            <div class="balance-label">账户余额</div>
                            <div class="balance-value">¥{user_info.get("balance", 0):.2f}</div>
                        </div>
                        {role == "player" and '<button class="recharge-btn" onclick="openRecharge()">充值</button>' or ""}
                    </div>
                    
                    <div class="menu-list">
                        <div class="menu-item active" onclick="showTab('orders')">📋 我的订单</div>
                        {role == "player" and '<div class="menu-item" onclick="showTab(\'favorites\')">❤ 我的收藏</div>' or ""}
                        {role == "partner" and '<div class="menu-item" onclick="showTab(\'revenue\')">💰 收益管理</div>' or ""}
                        <div class="menu-item" onclick="location.href='/partner/workspace'">⚙️ 陪玩工作台</div>
                    </div>
                </aside>
                
                <div class="main-area">
                    <div id="tab-orders" class="tab-content">
                        <div class="section-card">
                            <h3 class="section-title">我的订单</h3>
                            {orders_html}
                            {not orders and "<p style='text-align:center;color:#666'>暂无订单</p>" or ""}
                        </div>
                    </div>
                    
                    <div id="tab-favorites" class="tab-content" style="display:none">
                        <div class="section-card">
                            <h3 class="section-title">我的收藏</h3>
                            {favorites_html}
                            {not favorites and "<p style='text-align:center;color:#666'>暂无收藏</p>" or ""}
                        </div>
                    </div>
                    
                    <div id="tab-revenue" class="tab-content" style="display:none">
                        {revenue_html}
                    </div>
                </div>
            </div>
        </div>
        
        {get_footer()}
        
        <script>
            function showTab(tab) {{
                document.querySelectorAll('.menu-item').forEach(item => item.classList.remove('active'));
                event.target.classList.add('active');
                document.querySelectorAll('.tab-content').forEach(content => content.style.display = 'none');
                document.getElementById('tab-' + tab).style.display = 'block';
            }}
            
            function openRecharge() {{
                const amount = prompt('请输入充值金额:');
                if (amount) {{
                    fetch('/api/v1/player/recharge', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ amount: parseFloat(amount) }})
                    }}).then(res => res.json()).then(data => {{
                        alert(data.msg);
                        if (data.code == 200) location.reload();
                    }});
                }}
            }}
            
            function startOrder(order_id) {{
                fetch('/api/v1/order/update', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ order_id, status: 'in_progress' }})
                }}).then(res => res.json()).then(data => {{
                    alert(data.msg);
                    if (data.code == 200) location.reload();
                }});
            }}
            
            function completeOrder(order_id) {{
                fetch('/api/v1/order/update', {{
                    method: 'POST',
                    headers: {{ 'Content-Type': 'application/json' }},
                    body: JSON.stringify({{ order_id, status: 'completed' }})
                }}).then(res => res.json()).then(data => {{
                    alert(data.msg);
                    if (data.code == 200) location.reload();
                }});
            }}
            
            function rateOrder(order_id) {{
                const rating = parseInt(prompt('请输入评分(1-5):'));
                const comment = prompt('请输入评价内容:');
                if (rating && comment) {{
                    fetch('/api/v1/order/comment', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ order_id, rating, comment }})
                    }}).then(res => res.json()).then(data => {{
                        alert(data.msg);
                        if (data.code == 200) location.reload();
                    }});
                }}
            }}
            
            function applyRefund(order_id) {{
                const reason = prompt('请输入退款原因:');
                if (reason) {{
                    fetch('/api/v1/order/refund', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ order_id, reason }})
                    }}).then(res => res.json()).then(data => {{
                        alert(data.msg);
                        if (data.code == 200) location.reload();
                    }});
                }}
            }}
            
            function applyWithdraw() {{
                const amount = parseFloat(prompt('请输入提现金额:'));
                if (amount) {{
                    fetch('/api/v1/partner/withdraw', {{
                        method: 'POST',
                        headers: {{ 'Content-Type': 'application/json' }},
                        body: JSON.stringify({{ amount }})
                    }}).then(res => res.json()).then(data => {{
                        alert(data.msg);
                        if (data.code == 200) location.reload();
                    }});
                }}
            }}
        </script>
    </body>
    </html>
    '''