from template.home_html import get_header, get_footer

def get_forum_page(user_info=None, posts=None, categories=None):
    category_options = ""
    if categories:
        category_options = ''.join([f'<option value="{c}">{c}</option>' for c in categories])
    
    posts_html = ""
    if posts:
        for post in posts:
            posts_html += f'''
            <div class="post-card" onclick="location.href='/forum/post/{post["id"]}'">
                <div class="post-header">
                    <img src="{post.get("avatar", f"https://api.dicebear.com/7.x/avataaars/svg?seed={post.get("author", "user")}")}" class="post-avatar" alt="头像">
                    <div class="post-author-info">
                        <span class="post-author">{post["author"]}</span>
                        <span class="post-time">{post["create_time"]}</span>
                    </div>
                    <span class="post-category">{post["category"]}</span>
                </div>
                <h3 class="post-title">{post["title"]}</h3>
                <p class="post-content">{post["content"][:100]}...</p>
                <div class="post-footer">
                    <span class="post-stat">👁️ {post.get("views", 0)}</span>
                    <span class="post-stat">💬 {post.get("replies", 0)}</span>
                    <span class="post-stat">👍 {post.get("likes", 0)}</span>
                </div>
            </div>
            '''
    else:
        posts_html = '<div class="empty-state"><p>暂无帖子，快来发表第一篇吧！</p></div>'

    return f'''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>游戏论坛 - AI陪玩推荐平台</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, sans-serif; background: #0a0a14; color: #fff; min-height: 100vh; }}
        a {{ text-decoration: none; color: inherit; }}

        .site-header {{
            background: rgba(15, 15, 25, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            position: sticky;
            top: 0;
            z-index: 1000;
        }}
        .header-container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            height: 72px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        .logo {{ display: flex; align-items: center; gap: 10px; }}
        .logo-icon {{ font-size: 36px; }}
        .logo-text {{
            font-size: 26px;
            font-weight: 700;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .main-nav {{ display: flex; gap: 8px; }}
        .nav-item {{
            padding: 10px 20px;
            color: #9ca3af;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }}
        .nav-item:hover {{ color: #00d4ff; background: rgba(0, 212, 255, 0.08); }}
        .nav-item.active {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}
        .nav-right {{ display: flex; align-items: center; gap: 16px; }}
        .nav-link {{ padding: 8px 16px; color: #9ca3af; border-radius: 10px; }}
        .nav-link:hover {{ color: #00d4ff; }}
        .nav-link.register-btn {{ background: linear-gradient(135deg, #00d4ff, #7c3aed); color: #fff; }}
        .nav-link.balance {{ color: #4ade80; font-weight: 600; }}
        .user-area {{
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 16px;
            border-radius: 16px;
            cursor: pointer;
            position: relative;
        }}
        .user-avatar {{ width: 40px; height: 40px; border-radius: 50%; border: 2px solid rgba(0, 212, 255, 0.5); }}
        .user-name {{ font-weight: 500; color: #fff; }}
        .user-dropdown {{
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: rgba(20, 20, 35, 0.98);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 8px;
            min-width: 180px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
        }}
        .user-area:hover .user-dropdown {{ opacity: 1; visibility: visible; transform: translateY(0); }}
        .dropdown-item {{
            display: block;
            padding: 12px 16px;
            color: #9ca3af;
            border-radius: 10px;
        }}
        .dropdown-item:hover {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}

        .main-container {{
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 24px;
        }}

        .page-header {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
        }}

        .page-title {{
            font-size: 32px;
            font-weight: 700;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}

        .post-btn {{
            padding: 12px 24px;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            color: #fff;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }}

        .post-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(0, 212, 255, 0.3);
        }}

        .filter-bar {{
            display: flex;
            gap: 12px;
            margin-bottom: 24px;
            align-items: center;
        }}

        .filter-select {{
            padding: 10px 16px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 10px;
            color: #fff;
            font-size: 15px;
        }}

        .filter-select option {{ background: #1a1a2e; color: #fff; }}

        .post-grid {{
            display: flex;
            flex-direction: column;
            gap: 20px;
        }}

        .post-card {{
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 20px;
            padding: 28px;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.06);
        }}

        .post-card:hover {{
            transform: translateY(-4px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
            border-color: rgba(0, 212, 255, 0.2);
        }}

        .post-header {{
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 16px;
        }}

        .post-avatar {{
            width: 56px;
            height: 56px;
            border-radius: 50%;
            border: 3px solid rgba(0, 212, 255, 0.3);
        }}

        .post-author-info {{
            flex: 1;
        }}

        .post-author {{
            display: block;
            font-weight: 600;
            color: #fff;
        }}

        .post-time {{
            font-size: 13px;
            color: #6b7280;
        }}

        .post-category {{
            padding: 6px 16px;
            background: linear-gradient(135deg, rgba(124, 58, 237, 0.2), rgba(124, 58, 237, 0.1));
            color: #a78bfa;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 500;
        }}

        .post-title {{
            font-size: 20px;
            font-weight: 600;
            color: #fff;
            margin-bottom: 12px;
            line-height: 1.4;
        }}

        .post-content {{
            font-size: 15px;
            color: #9ca3af;
            line-height: 1.6;
            margin-bottom: 16px;
        }}

        .post-footer {{
            display: flex;
            gap: 24px;
        }}

        .post-stat {{
            font-size: 14px;
            color: #6b7280;
        }}

        .empty-state {{
            text-align: center;
            padding: 60px;
            color: #6b7280;
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 20px;
        }}

        .modal {{
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.8);
            backdrop-filter: blur(10px);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }}

        .modal.show {{ display: flex; }}

        .modal-content {{
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 24px;
            padding: 40px;
            width: 90%;
            max-width: 600px;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }}

        .modal-title {{
            font-size: 24px;
            font-weight: 600;
            margin-bottom: 24px;
        }}

        .modal-form {{
            display: flex;
            flex-direction: column;
            gap: 20px;
        }}

        .form-group {{
            display: flex;
            flex-direction: column;
        }}

        .form-label {{
            font-size: 14px;
            color: #9ca3af;
            margin-bottom: 8px;
        }}

        .form-input, .form-textarea, .form-select {{
            width: 100%;
            padding: 14px 16px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
        }}

        .form-textarea {{
            min-height: 200px;
            resize: vertical;
        }}

        .form-input:focus, .form-textarea:focus, .form-select:focus {{
            outline: none;
            border-color: #00d4ff;
            background: rgba(0, 212, 255, 0.05);
        }}

        .form-select option {{ background: #1a1a2e; color: #fff; }}

        .modal-actions {{
            display: flex;
            gap: 16px;
            margin-top: 24px;
        }}

        .modal-btn {{
            flex: 1;
            padding: 14px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }}

        .modal-btn.cancel {{
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }}

        .modal-btn.submit {{
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            color: #fff;
        }}

        .modal-btn:hover {{ transform: translateY(-2px); }}

        .site-footer {{
            background: rgba(15, 15, 25, 0.95);
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            padding: 60px 24px 30px;
            margin-top: 80px;
        }}
        .footer-content {{
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
        }}
        .footer-section h4 {{ font-size: 18px; color: #fff; margin-bottom: 16px; }}
        .footer-section p, .footer-section a {{
            color: #6b7280;
            font-size: 14px;
            line-height: 2;
            display: block;
        }}
        .footer-section a:hover {{ color: #00d4ff; }}
        .footer-bottom {{
            max-width: 1400px;
            margin: 40px auto 0;
            padding-top: 24px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
            text-align: center;
            color: #6b7280;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    {get_header(user_info, 'forum')}
    
    <div class="main-container">
        <div class="page-header">
            <h1 class="page-title">📢 游戏论坛</h1>
            <button class="post-btn" onclick="openPostModal()">✏️ 发表帖子</button>
        </div>
        
        <div class="filter-bar">
            <select class="filter-select" id="category">
                <option value="">全部分类</option>
                {category_options}
            </select>
            <button class="filter-btn" style="padding: 10px 20px; background: rgba(0,212,255,0.1); border: 1px solid rgba(0,212,255,0.3); color: #00d4ff; border-radius: 10px; cursor: pointer;" onclick="filterPosts()">筛选</button>
        </div>
        
        <div class="post-grid">
            {posts_html}
        </div>
    </div>
    
    <div class="modal" id="postModal">
        <div class="modal-content">
            <h2 class="modal-title">✏️ 发表帖子</h2>
            <form class="modal-form" onsubmit="submitPost(event)">
                <div class="form-group">
                    <label class="form-label">帖子标题</label>
                    <input type="text" class="form-input" id="post_title" placeholder="请输入帖子标题" required>
                </div>
                <div class="form-group">
                    <label class="form-label">分类</label>
                    <select class="form-select" id="post_category" required>
                        <option value="">请选择分类</option>
                        {category_options}
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">帖子内容</label>
                    <textarea class="form-textarea" id="post_content" placeholder="请输入帖子内容..." required></textarea>
                </div>
                <div class="modal-actions">
                    <button type="button" class="modal-btn cancel" onclick="closeModal()">取消</button>
                    <button type="submit" class="modal-btn submit">发表</button>
                </div>
            </form>
        </div>
    </div>
    
    {get_footer()}
    
    <script>
        function openPostModal() {{
            document.getElementById('postModal').classList.add('show');
        }}
        
        function closeModal() {{
            document.getElementById('postModal').classList.remove('show');
        }}
        
        document.getElementById('postModal').addEventListener('click', function(e) {{
            if (e.target === this) closeModal();
        }});
        
        function submitPost(e) {{
            e.preventDefault();
            const title = document.getElementById('post_title').value;
            const category = document.getElementById('post_category').value;
            const content = document.getElementById('post_content').value;
            
            fetch('/api/v1/forum/post', {{
                method: 'POST',
                headers: {{ 'Content-Type': 'application/json' }},
                body: JSON.stringify({{ title, category, content }})
            }}).then(res => res.json()).then(data => {{
                if (data.code == 200) {{
                    alert('发表成功！');
                    location.reload();
                }} else {{
                    alert(data.msg);
                }}
            }});
        }}
        
        function filterPosts() {{
            const category = document.getElementById('category').value;
            if (category) {{
                location.href = '/forum?category=' + encodeURIComponent(category);
            }} else {{
                location.href = '/forum';
            }}
        }}
    </script>
</body>
</html>
    '''

def get_post_detail_page(user_info=None, post=None, comments=None):
    if not post:
        return "<h1>帖子不存在</h1>"
    
    comments_html = ""
    if comments:
        for comment in comments:
            comments_html += f'''
            <div class="comment-item">
                <img src="{comment.get("avatar", f"https://api.dicebear.com/7.x/avataaars/svg?seed={comment.get("author", "user")}")}" class="comment-avatar" alt="头像">
                <div class="comment-content">
                    <div class="comment-header">
                        <span class="comment-author">{comment["author"]}</span>
                        <span class="comment-time">{comment["create_time"]}</span>
                    </div>
                    <p class="comment-text">{comment["content"]}</p>
                </div>
            </div>
            '''
    else:
        comments_html = '<p class="no-comments">暂无评论，快来抢沙发！</p>'

    avatar_url = post.get("avatar", f"https://api.dicebear.com/7.x/avataaars/svg?seed={post.get('author', 'user')}")
    
    return f'''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{post["title"]} - 游戏论坛</title>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Noto Sans SC', -apple-system, BlinkMacSystemFont, sans-serif; background: #0a0a14; color: #fff; min-height: 100vh; }}
        a {{ text-decoration: none; color: inherit; }}

        .site-header {{
            background: rgba(15, 15, 25, 0.95);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            position: sticky;
            top: 0;
            z-index: 1000;
        }}
        .header-container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            height: 72px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        .logo {{ display: flex; align-items: center; gap: 10px; }}
        .logo-icon {{ font-size: 36px; }}
        .logo-text {{
            font-size: 26px;
            font-weight: 700;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .main-nav {{ display: flex; gap: 8px; }}
        .nav-item {{
            padding: 10px 20px;
            color: #9ca3af;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }}
        .nav-item:hover {{ color: #00d4ff; background: rgba(0, 212, 255, 0.08); }}
        .nav-item.active {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}
        .nav-right {{ display: flex; align-items: center; gap: 16px; }}
        .nav-link {{ padding: 8px 16px; color: #9ca3af; border-radius: 10px; }}
        .nav-link:hover {{ color: #00d4ff; }}
        .nav-link.register-btn {{ background: linear-gradient(135deg, #00d4ff, #7c3aed); color: #fff; }}
        .nav-link.balance {{ color: #4ade80; font-weight: 600; }}
        .user-area {{
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 16px;
            border-radius: 16px;
            cursor: pointer;
            position: relative;
        }}
        .user-avatar {{ width: 40px; height: 40px; border-radius: 50%; border: 2px solid rgba(0, 212, 255, 0.5); }}
        .user-name {{ font-weight: 500; color: #fff; }}
        .user-dropdown {{
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: rgba(20, 20, 35, 0.98);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 8px;
            min-width: 180px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
        }}
        .user-area:hover .user-dropdown {{ opacity: 1; visibility: visible; transform: translateY(0); }}
        .dropdown-item {{
            display: block;
            padding: 12px 16px;
            color: #9ca3af;
            border-radius: 10px;
        }}
        .dropdown-item:hover {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}

        .main-container {{
            max-width: 800px;
            margin: 0 auto;
            padding: 40px 24px;
        }}

        .back-link {{
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #00d4ff;
            margin-bottom: 24px;
            font-size: 16px;
        }}

        .back-link:hover {{ text-decoration: underline; }}

        .post-detail {{
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 24px;
            padding: 40px;
            border: 1px solid rgba(255, 255, 255, 0.06);
            margin-bottom: 32px;
        }}

        .post-header {{
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 24px;
        }}

        .post-avatar {{
            width: 64px;
            height: 64px;
            border-radius: 50%;
            border: 3px solid rgba(0, 212, 255, 0.3);
        }}

        .post-author-info {{
            flex: 1;
        }}

        .post-author {{
            display: block;
            font-weight: 600;
            font-size: 18px;
            color: #fff;
        }}

        .post-time {{
            font-size: 14px;
            color: #6b7280;
        }}

        .post-category {{
            padding: 8px 20px;
            background: linear-gradient(135deg, rgba(124, 58, 237, 0.2), rgba(124, 58, 237, 0.1));
            color: #a78bfa;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 500;
        }}

        .post-title {{
            font-size: 28px;
            font-weight: 700;
            color: #fff;
            margin-bottom: 24px;
            line-height: 1.4;
        }}

        .post-content {{
            font-size: 16px;
            color: #e0e0e0;
            line-height: 1.8;
            white-space: pre-wrap;
        }}

        .post-footer {{
            display: flex;
            gap: 32px;
            margin-top: 32px;
            padding-top: 24px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
        }}

        .post-stat {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 15px;
            color: #9ca3af;
        }}

        .comment-section {{
            background: linear-gradient(145deg, #1a1a2e 0%, #16213e 100%);
            border-radius: 24px;
            padding: 32px;
            border: 1px solid rgba(255, 255, 255, 0.06);
        }}

        .comment-title {{
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }}

        .comment-title::before {{
            content: '';
            width: 4px;
            height: 20px;
            background: linear-gradient(180deg, #00d4ff, #7c3aed);
            border-radius: 2px;
        }}

        .comment-list {{
            display: flex;
            flex-direction: column;
            gap: 20px;
            margin-bottom: 32px;
        }}

        .comment-item {{
            display: flex;
            gap: 16px;
            padding: 20px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 16px;
        }}

        .comment-avatar {{
            width: 48px;
            height: 48px;
            border-radius: 50%;
            border: 2px solid rgba(0, 212, 255, 0.3);
            flex-shrink: 0;
        }}

        .comment-content {{
            flex: 1;
        }}

        .comment-header {{
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
        }}

        .comment-author {{
            font-weight: 600;
            color: #fff;
        }}

        .comment-time {{
            font-size: 12px;
            color: #6b7280;
        }}

        .comment-text {{
            font-size: 15px;
            color: #9ca3af;
            line-height: 1.6;
        }}

        .no-comments {{
            text-align: center;
            color: #6b7280;
            padding: 40px;
        }}

        .comment-form {{
            display: flex;
            flex-direction: column;
            gap: 16px;
        }}

        .comment-textarea {{
            width: 100%;
            padding: 16px;
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            min-height: 100px;
            resize: vertical;
        }}

        .comment-textarea:focus {{
            outline: none;
            border-color: #00d4ff;
            background: rgba(0, 212, 255, 0.05);
        }}

        .comment-btn {{
            align-self: flex-end;
            padding: 12px 32px;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }}

        .comment-btn:hover {{
            transform: translateY(-2px);
            box-shadow: 0 10px 30px rgba(0, 212, 255, 0.3);
        }}

        .site-footer {{
            background: rgba(15, 15, 25, 0.95);
            border-top: 1px solid rgba(255, 255, 255, 0.08);
            padding: 60px 24px 30px;
            margin-top: 80px;
        }}
        .footer-content {{
            max-width: 1400px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 40px;
        }}
        .footer-section h4 {{ font-size: 18px; color: #fff; margin-bottom: 16px; }}
        .footer-section p, .footer-section a {{
            color: #6b7280;
            font-size: 14px;
            line-height: 2;
            display: block;
        }}
        .footer-section a:hover {{ color: #00d4ff; }}
        .footer-bottom {{
            max-width: 1400px;
            margin: 40px auto 0;
            padding-top: 24px;
            border-top: 1px solid rgba(255, 255, 255, 0.06);
            text-align: center;
            color: #6b7280;
            font-size: 14px;
        }}
    </style>
</head>
<body>
    {get_header(user_info)}
    
    <div class="main-container">
        <a href="/forum" class="back-link">← 返回论坛</a>
        
        <div class="post-detail">
            <div class="post-header">
                <img src="{avatar_url}" class="post-avatar" alt="头像">
                <div class="post-author-info">
                    <span class="post-author">{post["author"]}</span>
                    <span class="post-time">{post["create_time"]}</span>
                </div>
                <span class="post-category">{post["category"]}</span>
            </div>
            
            <h1 class="post-title">{post["title"]}</h1>
            <div class="post-content">{post["content"]}</div>
            
            <div class="post-footer">
                <span class="post-stat">👁️ {post.get("views", 0)}</span>
                <span class="post-stat">💬 {post.get("replies", 0)}</span>
                <span class="post-stat">👍 {post.get("likes", 0)}</span>
            </div>
        </div>
        
        <div class="comment-section">
            <h3 class="comment-title">💬 评论 ({comments and len(comments) or 0})</h3>
            
            <div class="comment-list">
                {comments_html}
            </div>
            
            <form class="comment-form" onsubmit="submitComment(event)">
                <textarea class="comment-textarea" id="comment_content" placeholder="写下你的评论..." required></textarea>
                <input type="hidden" id="post_id" value="{post["id"]}">
                <button type="submit" class="comment-btn">发表评论</button>
            </form>
        </div>
    </div>
    
    {get_footer()}
    
    <script>
        function submitComment(e) {{
            e.preventDefault();
            const content = document.getElementById('comment_content').value;
            const post_id = document.getElementById('post_id').value;
            
            fetch('/api/v1/forum/comment', {{
                method: 'POST',
                headers: {{ 'Content-Type': 'application/json' }},
                body: JSON.stringify({{ post_id, content }})
            }}).then(res => res.json()).then(data => {{
                if (data.code == 200) {{
                    alert('评论成功！');
                    location.reload();
                }} else {{
                    alert(data.msg);
                }}
            }});
        }}
    </script>
</body>
</html>
    '''