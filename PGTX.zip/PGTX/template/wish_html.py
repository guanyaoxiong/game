from template.home_html import get_header, get_footer, get_partner_card

def get_wish_page(user_info=None, games=None, voices=None, results=None):
    game_options = ""
    if games:
        game_options = ''.join([f'<option value="{g}">{g}</option>' for g in games])
    
    voice_options = ""
    if voices:
        voice_options = ''.join([f'<option value="{v}">{v}</option>' for v in voices])
    
    result_html = ""
    if results:
        for p in results:
            result_html += get_partner_card(p, p.get("match_rate"))
    
    return f'''
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>心愿单匹配</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #161a29; color: #fff; }}
        .container {{ max-width: 1400px; margin: 0 auto; padding: 0 24px; }}
        
        .site-header {{
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f0f1f 100%);
            backdrop-filter: blur(20px);
            padding: 0;
            position: sticky;
            top: 0;
            z-index: 1000;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }}
        .header-container {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            height: 72px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }}
        .logo {{ display: flex; align-items: center; gap: 10px; text-decoration: none; }}
        .logo-icon {{ font-size: 36px; }}
        .logo-text {{
            font-size: 26px;
            font-weight: 700;
            background: linear-gradient(135deg, #00d4ff, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        .main-nav {{ display: flex; gap: 8px; }}
        .nav-item {{
            padding: 10px 20px;
            color: #9ca3af;
            text-decoration: none;
            border-radius: 12px;
            transition: all 0.3s ease;
            font-weight: 500;
        }}
        .nav-item:hover {{ color: #00d4ff; background: rgba(0, 212, 255, 0.08); }}
        .nav-item.active {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}
        .nav-right {{ display: flex; align-items: center; gap: 16px; }}
        .nav-link {{
            padding: 8px 16px;
            color: #9ca3af;
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s ease;
        }}
        .nav-link:hover {{ color: #00d4ff; }}
        .nav-link.register-btn {{ background: linear-gradient(135deg, #00d4ff, #7c3aed); color: #fff; }}
        .nav-link.balance {{ color: #4ade80; font-weight: 600; }}
        .user-area {{
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 6px 16px;
            border-radius: 16px;
            cursor: pointer;
            position: relative;
        }}
        .user-avatar {{
            width: 40px;
            height: 40px;
            border-radius: 50%;
            border: 2px solid rgba(0, 212, 255, 0.5);
        }}
        .user-name {{ font-weight: 500; color: #fff; }}
        .user-dropdown {{
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 8px;
            background: rgba(20, 20, 35, 0.98);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 16px;
            padding: 8px;
            min-width: 180px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
        }}
        .user-area:hover .user-dropdown {{ opacity: 1; visibility: visible; transform: translateY(0); }}
        .dropdown-item {{
            display: block;
            padding: 12px 16px;
            color: #9ca3af;
            text-decoration: none;
            border-radius: 10px;
        }}
        .dropdown-item:hover {{ background: rgba(0, 212, 255, 0.1); color: #00d4ff; }}

        .page-title {{ font-size: 32px; margin: 40px 0; text-align: center; }}
        
        .wish-form {{ background: #222740; border-radius: 16px; padding: 40px; margin-bottom: 40px; }}
        .form-title {{ font-size: 24px; margin-bottom: 32px; text-align: center; }}
        .form-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 24px; }}
        .form-group {{ display: flex; flex-direction: column; }}
        .form-label {{ font-size: 14px; color: #999; margin-bottom: 10px; }}
        .form-input, .form-select {{ padding: 14px; background: #161a29; border: 1px solid #333; border-radius: 10px; color: #fff; font-size: 16px; }}
        .form-input:focus, .form-select:focus {{ border-color: #00d4ff; outline: none; }}
        .form-row {{ display: flex; gap: 12px; }}
        .form-row .form-input {{ flex: 1; }}
        .match-btn {{ grid-column: 1 / -1; padding: 18px; background: linear-gradient(135deg, #00d4ff, #7c3aed); border: none; border-radius: 10px; color: #fff; font-size: 20px; cursor: pointer; margin-top: 16px; }}
        
        .result-section {{ margin-top: 40px; }}
        .result-title {{ font-size: 28px; margin-bottom: 32px; display: flex; align-items: center; gap: 12px; }}
        .result-title span {{ display: inline-block; width: 4px; height: 28px; background: linear-gradient(135deg, #00d4ff, #7c3aed); border-radius: 2px; }}
        
        .partner-grid {{ display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 24px; }}
        .partner-card {{
            background: #222740;
            border-radius: 16px;
            overflow: hidden;
            cursor: pointer;
            transition: all 0.3s ease;
            border: 1px solid rgba(255, 255, 255, 0.05);
        }}
        .partner-card:hover {{ transform: translateY(-6px); border-color: rgba(0, 212, 255, 0.3); }}
        .match-tag {{
            position: absolute;
            top: 16px;
            right: 16px;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }}
        .match-tag.gold {{ background: linear-gradient(135deg, #ffd700, #ffaa00); color: #000; }}
        .match-tag.blue {{ background: #00d4ff; color: #fff; }}
        .match-tag.gray {{ background: #666; color: #fff; }}
        .card-header {{ padding: 24px; position: relative; }}
        .partner-avatar {{
            width: 72px;
            height: 72px;
            border-radius: 50%;
            border: 3px solid rgba(0, 212, 255, 0.3);
        }}
        .status-indicator {{
            display: flex;
            align-items: center;
            gap: 6px;
            margin-top: 10px;
        }}
        .status-dot {{
            width: 10px;
            height: 10px;
            border-radius: 50%;
        }}
        .status-indicator.online .status-dot {{ background: #4ade80; }}
        .status-indicator.offline .status-dot {{ background: #666; }}
        .status-text {{ font-size: 12px; color: #9ca3af; }}
        .card-body {{ padding: 0 24px 16px; }}
        .partner-name {{ font-size: 20px; margin-bottom: 10px; }}
        .partner-tags {{ display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }}
        .partner-tag {{
            padding: 4px 10px;
            background: rgba(0, 212, 255, 0.1);
            color: #00d4ff;
            border-radius: 6px;
            font-size: 12px;
        }}
        .partner-info {{ display: flex; flex-direction: column; gap: 4px; }}
        .info-item {{ font-size: 14px; color: #9ca3af; }}
        .card-footer {{ padding: 16px 24px; background: rgba(0,0,0,0.2); display: flex; justify-content: space-between; align-items: center; }}
        .price-section {{ display: flex; align-items: baseline; gap: 2px; }}
        .price-label {{ font-size: 12px; color: #9ca3af; }}
        .price-value {{ font-size: 24px; color: #ff6633; font-weight: bold; }}
        .price-unit {{ font-size: 12px; color: #9ca3af; }}
        .rating-section {{ font-size: 14px; color: #4ade80; }}
        .card-stats {{
            padding: 16px 24px;
            display: flex;
            justify-content: space-around;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }}
        .stat-item {{ text-align: center; }}
        .stat-value {{ display: block; font-size: 18px; font-weight: bold; color: #fff; }}
        .stat-label {{ font-size: 12px; color: #9ca3af; }}
        
        .site-footer {{
            background: #222740;
            padding: 48px 0 24px;
            margin-top: 60px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
        }}
        .footer-content {{
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 24px;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 48px;
        }}
        .footer-section h4 {{ font-size: 18px; margin-bottom: 16px; }}
        .footer-section p, .footer-section a {{ color: #9ca3af; }}
        .footer-section a {{ display: block; margin-bottom: 8px; text-decoration: none; }}
        .footer-section a:hover {{ color: #00d4ff; }}
        .footer-bottom {{
            text-align: center;
            padding-top: 24px;
            margin-top: 32px;
            border-top: 1px solid rgba(255, 255, 255, 0.05);
            color: #666;
        }}
    </style>
</head>
<body>
    {get_header(user_info)}
    
    <div class="container">
        <h1 class="page-title">🎯 心愿单匹配</h1>
        
        <div class="wish-form">
            <h3 class="form-title">填写你的需求，AI为你精准匹配</h3>
            <form class="form-grid" onsubmit="submitWish(event)">
                <div class="form-group">
                    <label class="form-label">🎮 目标游戏</label>
                    <select class="form-select" id="game" required>
                        <option value="">请选择游戏</option>
                        {game_options}
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">💰 预算区间</label>
                    <div class="form-row">
                        <input type="number" class="form-input" id="budget_min" placeholder="最低" min="0">
                        <input type="number" class="form-input" id="budget_max" placeholder="最高" min="0">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">🎤 声线偏好</label>
                    <select class="form-select" id="voice">
                        <option value="不限">不限</option>
                        {voice_options}
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">🎯 匹配需求</label>
                    <select class="form-select" id="demand">
                        <option value="上分">上分冲段</option>
                        <option value="娱乐">娱乐聊天</option>
                        <option value="通宵">通宵开黑</option>
                        <option value="教学">技术教学</option>
                    </select>
                </div>
                <button type="submit" class="match-btn">🚀 开始AI匹配</button>
            </form>
        </div>
        
        <div class="result-section">
            <div class="result-title"><span></span>匹配结果</div>
            <div class="partner-grid">{result_html}</div>
            {not results and "<p style='text-align:center;color:#666;padding:40px'>暂无匹配结果，请调整筛选条件</p>" or ""}
        </div>
    </div>
    
    {get_footer()}
    
    <script>
        function submitWish(e) {{
            e.preventDefault();
            const game = document.getElementById('game').value;
            const budget_min = parseFloat(document.getElementById('budget_min').value) || 0;
            const budget_max = parseFloat(document.getElementById('budget_max').value) || 9999;
            const voice = document.getElementById('voice').value;
            
            fetch('/api/v1/recommend/wish', {{
                method: 'POST',
                headers: {{ 'Content-Type': 'application/json' }},
                body: JSON.stringify({{ game, budget_min, budget_max, voice }})
            }}).then(res => res.json()).then(data => {{
                if (data.code == 200) {{
                    location.href = '/wish?game=' + encodeURIComponent(game) + 
                        '&budget_min=' + budget_min + '&budget_max=' + budget_max + '&voice=' + encodeURIComponent(voice);
                }}
            }});
        }}
    </script>
</body>
</html>
'''
