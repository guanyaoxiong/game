import json
import os

DATA_PATH = "data/"

if not os.path.exists(DATA_PATH):
    os.mkdir(DATA_PATH)

def read_json(file_name):
    file_path = os.path.join(DATA_PATH, file_name)
    if not os.path.exists(file_path):
        return []
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)

def write_json(file_name, data):
    file_path = os.path.join(DATA_PATH, file_name)
    with open(file_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def get_next_id(file_name):
    data = read_json(file_name)
    if not data:
        return 1
    max_id = max(item.get("id", item.get("user_id", item.get("partner_id", 0))) for item in data)
    return max_id + 1