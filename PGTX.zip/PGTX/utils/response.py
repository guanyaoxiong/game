import json

def json_response(code=200, msg="操作成功", data=None):
    response = {"code": code, "msg": msg, "data": data or {}}
    return json.dumps(response, ensure_ascii=False).encode("utf-8")

def html_response(html_content):
    return html_content.encode("utf-8")